package com.jarvis.ai.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class JarvisNotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val title = sbn.notification.extras.getString("android.title") ?: return
        val text = sbn.notification.extras.getString("android.text") ?: ""
        val entry = "$title: $text"
        recentNotifications.add(entry)
        if (recentNotifications.size > 10) recentNotifications.removeAt(0)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {}

    companion object {
        private val recentNotifications = mutableListOf<String>()
        fun getRecentNotifications(): List<String> = recentNotifications.toList()
    }
}
