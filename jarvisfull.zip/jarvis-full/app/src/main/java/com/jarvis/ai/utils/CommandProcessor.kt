package com.jarvis.ai.utils

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.widget.Toast
import androidx.core.content.ContextCompat

class CommandProcessor(private val context: Context) {

    // Главный метод — вызывается из JarvisService
    fun processCommand(command: String): String? {
        val lower = command.lowercase().trim()

        // Звонок по имени контакта
        if (lower.startsWith("позвони") || lower.startsWith("набери") || lower.startsWith("вызови")) {
            val name = lower
                .removePrefix("позвони").removePrefix("набери").removePrefix("вызови")
                .replace("маме", "мама").replace("папе", "папа")
                .replace("другу", "").replace("подруге", "")
                .trim()
            return if (name.isNotBlank()) callContact(name) else "Укажите имя контакта, сэр."
        }

        return null // не наша команда
    }

    private fun callContact(contactName: String): String {
        // Проверяем разрешение
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            return "Нет разрешения на чтение контактов, сэр. Предоставьте доступ в настройках."
        }

        val phone = findPhoneByName(contactName)
        return if (phone != null) {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
            "Звоню $contactName, сэр."
        } else {
            // Попробуем более широкий поиск
            val phoneFuzzy = findPhoneByNameFuzzy(contactName)
            if (phoneFuzzy != null) {
                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${phoneFuzzy.second}"))
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent)
                "Звоню ${phoneFuzzy.first}, сэр."
            } else {
                "Контакт '$contactName' не найден в книге, сэр."
            }
        }
    }

    private fun findPhoneByName(name: String): String? {
        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        )
        cursor?.use {
            if (it.moveToFirst()) {
                return it.getString(it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER))
            }
        }
        return null
    }

    // Нечёткий поиск — ищет по первому слову имени
    private fun findPhoneByNameFuzzy(name: String): Pair<String, String>? {
        val firstName = name.split(" ").first()
        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$firstName%"),
            null
        )
        cursor?.use {
            if (it.moveToFirst()) {
                val displayName = it.getString(it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME))
                val phone = it.getString(it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER))
                return Pair(displayName, phone)
            }
        }
        return null
    }
}
