package com.jarvis.ai.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import android.Manifest
import android.content.pm.PackageManager
import com.jarvis.ai.R
import com.jarvis.ai.service.JarvisService
import com.jarvis.ai.utils.Prefs

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnStart   = findViewById<Button>(R.id.btnStart)
        val btnStop    = findViewById<Button>(R.id.btnStop)
        val btnSettings= findViewById<TextView>(R.id.btnSettings)
        val statusTv   = findViewById<TextView>(R.id.tvStatus)
        val ring1 = findViewById<android.view.View>(R.id.mainRing1)
        val ring2 = findViewById<android.view.View>(R.id.mainRing2)
        val ring3 = findViewById<android.view.View>(R.id.mainRing3)

        // Animate rings on main screen
        ring1.startAnimation(AnimationUtils.loadAnimation(this, R.anim.rotate_cw))
        ring2.startAnimation(AnimationUtils.loadAnimation(this, R.anim.rotate_ccw))
        ring3.startAnimation(AnimationUtils.loadAnimation(this, R.anim.rotate_cw_slow))

        btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        btnStart.setOnClickListener {
            if (Prefs.getApiKey(this).isBlank()) {
                Toast.makeText(this, "Сначала введите API ключ в настройках!", Toast.LENGTH_LONG).show()
                startActivity(Intent(this, SettingsActivity::class.java))
                return@setOnClickListener
            }
            if (!checkPermissions()) return@setOnClickListener
            startJarvis()
            statusTv.text = "● АКТИВЕН"
            statusTv.setTextColor(0xFF00FF88.toInt())
        }

        btnStop.setOnClickListener {
            stopService(Intent(this, JarvisService::class.java))
            statusTv.text = "● ОСТАНОВЛЕН"
            statusTv.setTextColor(0xFFFF3344.toInt())
        }
    }

    private fun checkPermissions(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            startActivityForResult(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
                1001
            )
            Toast.makeText(this, "Разрешите отображение поверх приложений", Toast.LENGTH_LONG).show()
            return false
        }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1002)
            return false
        }
        return true
    }

    private fun startJarvis() {
        val intent = Intent(this, JarvisService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
        else startService(intent)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 1001 && Settings.canDrawOverlays(this)) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startJarvis()
            else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1002)
        }
    }

    override fun onRequestPermissionsResult(req: Int, perms: Array<String>, results: IntArray) {
        super.onRequestPermissionsResult(req, perms, results)
        if (req == 1002 && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) {
            if (Settings.canDrawOverlays(this)) startJarvis()
        }
    }
}
