package com.jarvis.ai.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import android.Manifest
import android.content.pm.PackageManager
import com.jarvis.ai.R
import com.jarvis.ai.service.JarvisService
import com.jarvis.ai.utils.Prefs

class MainActivity : AppCompatActivity() {

    companion object {
        const val REQ_OVERLAY = 1001
        const val REQ_AUDIO   = 1002
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val apiKeyInput   = findViewById<EditText>(R.id.etApiKey)
        val wakeWordInput = findViewById<EditText>(R.id.etWakeWord)
        val btnSave       = findViewById<Button>(R.id.btnSave)
        val btnStart      = findViewById<Button>(R.id.btnStart)
        val btnStop       = findViewById<Button>(R.id.btnStop)
        val statusText    = findViewById<TextView>(R.id.tvStatus)

        // Load saved prefs
        apiKeyInput.setText(Prefs.getApiKey(this))
        wakeWordInput.setText(Prefs.getWakeWord(this))

        btnSave.setOnClickListener {
            val key = apiKeyInput.text.toString().trim()
            val wake = wakeWordInput.text.toString().trim().lowercase()
            if (key.isEmpty()) {
                Toast.makeText(this, "Введите API ключ!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            Prefs.saveApiKey(this, key)
            Prefs.saveWakeWord(this, wake.ifEmpty { "джарвис" })
            Toast.makeText(this, "Настройки сохранены ✓", Toast.LENGTH_SHORT).show()
        }

        btnStart.setOnClickListener {
            if (!checkAndRequestPermissions()) return@setOnClickListener
            startJarvisService()
            statusText.text = "● СТАТУС: АКТИВЕН"
            statusText.setTextColor(0xFF00FF88.toInt())
        }

        btnStop.setOnClickListener {
            stopService(Intent(this, JarvisService::class.java))
            statusText.text = "● СТАТУС: ОСТАНОВЛЕН"
            statusText.setTextColor(0xFFFF3344.toInt())
        }
    }

    private fun checkAndRequestPermissions(): Boolean {
        // 1) Overlay permission
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, REQ_OVERLAY)
            Toast.makeText(this, "Разрешите отображение поверх других приложений", Toast.LENGTH_LONG).show()
            return false
        }
        // 2) Microphone permission
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), REQ_AUDIO)
            return false
        }
        return true
    }

    private fun startJarvisService() {
        val intent = Intent(this, JarvisService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_OVERLAY && Settings.canDrawOverlays(this)) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED) {
                startJarvisService()
            } else {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), REQ_AUDIO)
            }
        }
    }

    override fun onRequestPermissionsResult(req: Int, perms: Array<String>, results: IntArray) {
        super.onRequestPermissionsResult(req, perms, results)
        if (req == REQ_AUDIO && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) {
            if (Settings.canDrawOverlays(this)) startJarvisService()
        }
    }
}
