package com.jarvis.ai.ui

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.jarvis.ai.R
import com.jarvis.ai.utils.Prefs

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val etApiKey    = findViewById<EditText>(R.id.etApiKey)
        val etWakeWord  = findViewById<EditText>(R.id.etWakeWord)
        val spinnerModel= findViewById<Spinner>(R.id.spinnerModel)
        val seekPitch   = findViewById<SeekBar>(R.id.seekPitch)
        val seekSpeed   = findViewById<SeekBar>(R.id.seekSpeed)
        val seekScroll  = findViewById<SeekBar>(R.id.seekScroll)
        val swVibrate   = findViewById<Switch>(R.id.swVibrate)
        val swAutostart = findViewById<Switch>(R.id.swAutostart)
        val btnColorBlue= findViewById<Button>(R.id.btnColorBlue)
        val btnColorGreen=findViewById<Button>(R.id.btnColorGreen)
        val btnColorRed = findViewById<Button>(R.id.btnColorRed)
        val btnColorGold= findViewById<Button>(R.id.btnColorGold)
        val btnSave     = findViewById<Button>(R.id.btnSave)
        val btnBack     = findViewById<Button>(R.id.btnBack)

        // Models spinner
        val models = arrayOf("gpt-4o-mini", "gpt-3.5-turbo", "gpt-4o", "gpt-4-turbo", "gpt-4")
        spinnerModel.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, models)

        // Load saved values
        etApiKey.setText(Prefs.getApiKey(this))
        etWakeWord.setText(Prefs.getWakeWord(this))
        val modelIdx = models.indexOf(Prefs.getModel(this)).coerceAtLeast(0)
        spinnerModel.setSelection(modelIdx)
        seekPitch.progress = ((Prefs.getPitch(this) - 0.5f) * 100).toInt().coerceIn(0, 100)
        seekSpeed.progress = ((Prefs.getSpeed(this) - 0.5f) * 100).toInt().coerceIn(0, 100)
        seekScroll.progress = ((Prefs.getScrollSpeed(this) - 1000) / 50).coerceIn(0, 100)
        swVibrate.isChecked = Prefs.getVibrate(this)
        swAutostart.isChecked = Prefs.getAutostart(this)

        // Color buttons
        btnColorBlue.setOnClickListener  { Prefs.saveColor(this, 0xFF00D4FF.toInt()); toast("Синий цвет") }
        btnColorGreen.setOnClickListener { Prefs.saveColor(this, 0xFF00FF88.toInt()); toast("Зелёный цвет") }
        btnColorRed.setOnClickListener   { Prefs.saveColor(this, 0xFFFF3344.toInt()); toast("Красный цвет") }
        btnColorGold.setOnClickListener  { Prefs.saveColor(this, 0xFFFFD700.toInt()); toast("Золотой цвет") }

        btnSave.setOnClickListener {
            val key = etApiKey.text.toString().trim()
            val wake = etWakeWord.text.toString().trim().lowercase().ifBlank { "джарвис" }
            if (key.isBlank()) { toast("Введите API ключ!"); return@setOnClickListener }

            Prefs.saveApiKey(this, key)
            Prefs.saveWakeWord(this, wake)
            Prefs.saveModel(this, spinnerModel.selectedItem.toString())
            Prefs.savePitch(this, 0.5f + seekPitch.progress / 100f)
            Prefs.saveSpeed(this, 0.5f + seekSpeed.progress / 100f)
            Prefs.saveScrollSpeed(this, 1000 + seekScroll.progress * 50)
            Prefs.saveVibrate(this, swVibrate.isChecked)
            Prefs.saveAutostart(this, swAutostart.isChecked)

            toast("Настройки сохранены ✓")
            finish()
        }

        btnBack.setOnClickListener { finish() }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
