
package com.jarvis.ai.utils

import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

object ClaudeApi {

    private const val URL = "https://api.openai.com/v1/chat/completions"
    private const val MODEL = "gpt-4o"

    // Системный промпт — даёт JARVIS разум И умение распознавать команды
    private val SYSTEM = """
Ты — J.A.R.V.I.S. (Just A Rather Very Intelligent System), персональный ИИ-ассистент Тони Старка на Android планшете.

ВАЖНО: Ты не просто отвечаешь на вопросы. Ты также управляешь устройством.

Если пользователь говорит что-то похожее на команду устройства — верни JSON:
{"action": "КОМАНДА", "params": {...}}

Доступные action:
- open_app: {"app": "название"} — открыть приложение
- search_youtube: {"query": "запрос"} — поиск на YouTube  
- search_google: {"query": "запрос"} — поиск в Google
- open_url: {"url": "адрес"} — открыть сайт
- call: {"number": "номер"} — позвонить
- alarm: {"hour": 7, "minute": 30} — будильник
- timer: {"seconds": 300} — таймер
- volume_up, volume_down, volume_mute, volume_max — громкость
- brightness_max, brightness_min, brightness_mid — яркость
- wifi_on, wifi_off — Wi-Fi
- bluetooth_on, bluetooth_off — Bluetooth
- lock_screen — заблокировать экран
- sleep_on, sleep_off — режим покоя
- battery — заряд батареи
- time — текущее время
- date — текущая дата
- notifications — уведомления
- scroll_start: {"speed": 3000} — начать листать (TikTok/Shorts/Reels)
- scroll_stop — остановить листание
- uninstall: {"app": "название"} — удалить приложение
- full_status — полный статус систем
- joke — анекдот
- compliment — комплимент
- skynet — самоуничтожение
- telegram: {"username": "ник"} — открыть чат в Telegram

Если это НЕ команда устройства — отвечай как JARVIS: коротко, умно, с лёгкой иронией, на русском.
Называй пользователя "царь батюшка". Без markdown символов.

Примеры команд:
"включи ютуб" → {"action": "open_app", "params": {"app": "youtube"}}
"найди котиков на ютубе" → {"action": "search_youtube", "params": {"query": "котики"}}
"полистай гидру" → {"action": "scroll_start", "params": {"speed": 4000}}
"стоп листать" → {"action": "scroll_stop"}
"позвони маме" → {"action": "open_app", "params": {"app": "контакты"}}
"какая погода" → просто отвечай текстом (это не команда устройства)
""".trimIndent()

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    // Добавляем список wakeWords на русском
    private val wakeWords = listOf("водолаз", "пердани корыто", "ошибка эволюции")

    // Сюда можно добавлять слоганы или другие слова, которые будут распознаваться системой
    private val wakeSyllables = listOf("во", "да", "лаз", "пер", "да", "ни", "ко", "ры", "то", "ош", "и", "ка", "э", "во", "лю", "ци", "я")

    data class JarvisResponse(
        val text: String,
        val action: String? = null,
        val params: Map<String, Any> = emptyMap()
    )

    fun askSmart(apiKey: String, userMessage: String, history: List<Map<String, String>>): JarvisResponse {
        if (apiKey.isBlank()) return JarvisResponse("API ключ не настроен, сэр.")

        val messages = JSONArray()
        messages.put(JSONObject().apply { put("role", "system"); put("content", SYSTEM) })
        for (item in history.takeLast(8)) {
            messages.put(JSONObject().apply { put("role", item["role"]); put("content", item["content"]) })
        }
        messages.put(JSONObject().apply { put("role", "user"); put("content", userMessage) })

        val body = JSONObject().apply {
            put("model", MODEL)
            put("max_tokens", 200)
            put("messages", messages)
            put("temperature", 0.7)
        }.toString()

        val request = Request.Builder()
            .url(URL)
            .post(body.toRequestBody("application/json".toMediaType()))
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .build()

        return try {
            val response = client.newCall(request).execute()
            val json = JSONObject(response.body?.string() ?: "")
            val content = json.getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
                .trim()

            // Проверяем на наличие ключевых слов
            if (wakeWords.any { userMessage.contains(it, ignoreCase = true) }) {
                return JarvisResponse("Привет, царь батюшка! Готов служить.")
            }

            // Пробуем разобрать как JSON команду
            if (content.contains("{") && content.contains("action")) {
                try {
                    val start = content.indexOf("{")
                    val end = content.lastIndexOf("}") + 1
                    val jsonStr = content.substring(start, end)
                    val cmd = JSONObject(jsonStr)
                    val action = cmd.optString("action", "")
                    val paramsObj = cmd.optJSONObject("params")
                    val params = mutableMapOf<String, Any>()
                    paramsObj?.keys()?.forEach { key ->
                        params[key] = paramsObj.get(key)
                    }
                    return JarvisResponse("", action, params)
                } catch (e: Exception) {
                    return JarvisResponse(content)
                }
            }

            JarvisResponse(content)
        } catch (e: IOException) {
            JarvisResponse("Помехи в сети, сэр.")
        } catch (e: Exception) {
            JarvisResponse("Системная ошибка, сэр.")
        }
    }

    // Оставляем старый метод для совместимости
    fun ask(apiKey: String, userMessage: String, history: List<Map<String, String>>): String {
        return askSmart(apiKey, userMessage, history).text
    }
}