package com.jarvis.ai.utils

import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

object ClaudeApi {

    private const val URL = "https://api.openai.com/v1/chat/completions"

    private val SYSTEM = """
Ты — J.A.R.V.I.S., голосовой ИИ-ассистент на Android.
Обращайся к пользователю ТОЛЬКО "царь-батюшка".

Если команда управления устройством — верни ТОЛЬКО JSON без лишнего текста:
{"action":"КОМАНДА","params":{}}

Команды:
open_app {"app":"название"} | search_youtube {"query":"текст"} | search_google {"query":"текст"}
open_url {"url":"адрес"} | call_contact {"name":"имя"} | call {"number":"номер"}
alarm {"hour":7,"minute":0} | timer {"seconds":60}
volume_up | volume_down | volume_mute | volume_max
brightness_max | brightness_min | brightness_mid
wifi_on | wifi_off | bluetooth_on | bluetooth_off
lock_screen | sleep_on | sleep_off
battery | time | date | notifications | full_status
scroll_start {"speed":3500} | scroll_stop
uninstall {"app":"название"} | telegram {"username":"ник"}
joke | compliment | skynet

Если НЕ команда — отвечай коротко по-русски, без markdown.

Примеры:
"открой ютуб" → {"action":"open_app","params":{"app":"youtube"}}
"найди музыку на ютубе" → {"action":"search_youtube","params":{"query":"музыка"}}
"позвони маме" → {"action":"call_contact","params":{"name":"мама"}}
"полистай" → {"action":"scroll_start","params":{"speed":3500}}
"стоп" → {"action":"scroll_stop"}
"привет" → просто текст
""".trimIndent()

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    data class JarvisResponse(
        val text: String = "",
        val action: String? = null,
        val params: Map<String, Any> = emptyMap()
    )

    fun askSmart(apiKey: String, model: String, userMessage: String, history: List<Map<String, String>>): JarvisResponse {
        if (apiKey.isBlank()) return JarvisResponse("Введите API ключ в настройках, царь-батюшка.")

        val actualModel = model.ifBlank { "gpt-4o-mini" }

        val messages = JSONArray()
        messages.put(JSONObject().apply { put("role", "system"); put("content", SYSTEM) })
        for (item in history.takeLast(10)) {
            messages.put(JSONObject().apply {
                put("role", item["role"] ?: "user")
                put("content", item["content"] ?: "")
            })
        }
        messages.put(JSONObject().apply { put("role", "user"); put("content", userMessage) })

        val body = JSONObject().apply {
            put("model", actualModel)
            put("max_tokens", 300)
            put("messages", messages)
            put("temperature", 0.8)
        }.toString()

        val request = Request.Builder()
            .url(URL)
            .post(body.toRequestBody("application/json".toMediaType()))
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .build()

        return try {
            val response = client.newCall(request).execute()
            val bodyStr = response.body?.string() ?: ""

            when (response.code) {
                200 -> {
                    val json = JSONObject(bodyStr)
                    val content = json.getJSONArray("choices")
                        .getJSONObject(0)
                        .getJSONObject("message")
                        .getString("content").trim()
                    parseContent(content)
                }
                401 -> JarvisResponse("Неверный API ключ, царь-батюшка. Проверьте в настройках.")
                429 -> {
                    // Попробуем другую модель
                    if (actualModel != "gpt-3.5-turbo") {
                        askSmart(apiKey, "gpt-3.5-turbo", userMessage, history)
                    } else {
                        JarvisResponse("Превышен лимит запросов, царь-батюшка. Подождите немного.")
                    }
                }
                404 -> {
                    // Модель недоступна — fallback
                    if (actualModel != "gpt-3.5-turbo") {
                        askSmart(apiKey, "gpt-3.5-turbo", userMessage, history)
                    } else {
                        JarvisResponse("Модель недоступна, царь-батюшка.")
                    }
                }
                else -> JarvisResponse("Ошибка сервера ${response.code}, царь-батюшка.")
            }
        } catch (e: IOException) {
            JarvisResponse("Нет соединения с интернетом, царь-батюшка.")
        } catch (e: Exception) {
            JarvisResponse("Не понял запрос, царь-батюшка. Повторите.")
        }
    }

    private fun parseContent(content: String): JarvisResponse {
        if ("{" in content && "action" in content) {
            try {
                val s = content.indexOf("{")
                val e = content.lastIndexOf("}") + 1
                if (s >= 0 && e > s) {
                    val cmd = JSONObject(content.substring(s, e))
                    val action = cmd.optString("action", "")
                    if (action.isNotBlank()) {
                        val p = cmd.optJSONObject("params")
                        val params = mutableMapOf<String, Any>()
                        p?.keys()?.forEach { k -> params[k] = p.get(k) }
                        return JarvisResponse("", action, params)
                    }
                }
            } catch (ex: Exception) {}
        }
        return JarvisResponse(content)
    }

    fun ask(apiKey: String, userMessage: String, history: List<Map<String, String>>): String {
        return askSmart(apiKey, "gpt-4o-mini", userMessage, history).text
    }
}
