package com.jarvis.ai.utils

import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

object ClaudeApi {

    private const val URL = "https://api.openai.com/v1/chat/completions"
    private const val MODEL = "gpt-4o"

    private val SYSTEM = """
Ты — J.A.R.V.I.S. (Just A Rather Very Intelligent System), персональный ИИ-ассистент Тони Старка.
Правила:
- Отвечай коротко: 1-3 предложения максимум. Ты голосовой ассистент — краткость важна.
- Официально-вежливый тон, лёгкая ирония. Называй "сэр" или "мистер Старк".
- Ты можешь управлять устройством: громкость, яркость, Wi-Fi, Bluetooth, открывать приложения.
- Если пользователь просит системную команду — отвечай коротко что выполнил.
- Отвечай ТОЛЬКО на русском языке.
- Никаких markdown-символов — только чистый текст для голоса.
""".trimIndent()

    private val client = OkHttpClient()

    fun ask(apiKey: String, userMessage: String, history: List<Map<String, String>>): String {
        if (apiKey.isBlank()) return "API ключ не настроен, сэр."

        val messages = JSONArray()
        messages.put(JSONObject().apply {
            put("role", "system")
            put("content", SYSTEM)
        })
        for (item in history.takeLast(10)) {
            messages.put(JSONObject().apply {
                put("role", item["role"])
                put("content", item["content"])
            })
        }
        messages.put(JSONObject().apply {
            put("role", "user")
            put("content", userMessage)
        })

        val body = JSONObject().apply {
            put("model", MODEL)
            put("max_tokens", 300)
            put("messages", messages)
        }.toString()

        val request = Request.Builder()
            .url(URL)
            .post(body.toRequestBody("application/json".toMediaType()))
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .build()

        return try {
            val response = client.newCall(request).execute()
            val json = JSONObject(response.body?.string() ?: "")
            json.getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
                .trim()
        } catch (e: IOException) {
            "Помехи в сети, сэр."
        } catch (e: Exception) {
            "Системная ошибка, сэр."
        }
    }
}
