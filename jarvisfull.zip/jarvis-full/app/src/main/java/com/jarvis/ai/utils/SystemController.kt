package com.jarvis.ai.utils

import android.app.NotificationManager
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.Settings
import com.jarvis.ai.service.JarvisNotificationListener

object SystemController {

    // Прозвища для JARVIS (его называют по-разному)
    private val jarvisNicknames = listOf(
        "водолаз", "корыто", "пердонюх", "джарвис", "jarvis",
        "жарвис", "харвис", "арвис", "эй", "слушай"
    )

    fun containsJarvisName(text: String): Boolean {
        val lower = text.lowercase()
        return jarvisNicknames.any { it in lower }
    }

    fun setVolume(ctx: Context, level: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.setStreamVolume(AudioManager.STREAM_MUSIC, level.coerceIn(0,100)*am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)/100, AudioManager.FLAG_SHOW_UI)
    }

    fun getVolume(ctx: Context): Int {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.getStreamVolume(AudioManager.STREAM_MUSIC)*100/am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    }

    fun volumeUp(ctx: Context) {
        (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager)
            .adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
    }

    fun volumeDown(ctx: Context) {
        (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager)
            .adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
    }

    fun setBrightness(ctx: Context, level: Int): Boolean {
        return try {
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, level.coerceIn(0,100)*255/100)
            true
        } catch (e: Exception) { false }
    }

    fun getBrightness(ctx: Context): Int {
        return try { Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS)*100/255 }
        catch (e: Exception) { -1 }
    }

    fun lockScreen(ctx: Context): String {
        return try {
            val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
            dpm.lockNow()
            "Экран заблокирован, царь-батюшка."
        } catch (e: Exception) { "Требуются права администратора, царь-батюшка." }
    }

    fun setSleepMode(ctx: Context, enable: Boolean): String {
        return try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.isNotificationPolicyAccessGranted) {
                if (enable) nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
                else nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
                if (enable) "Режим покоя активирован, царь-батюшка." else "Режим покоя отключён, царь-батюшка."
            } else {
                ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
                "Разрешите доступ в настройках, царь-батюшка."
            }
        } catch (e: Exception) { "Ошибка режима покоя, царь-батюшка." }
    }

    fun setWifi(ctx: Context, enable: Boolean): String {
        return try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                @Suppress("DEPRECATION")
                (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled = enable
                if (enable) "Wi-Fi включён, царь-батюшка." else "Wi-Fi выключен, царь-батюшка."
            } else {
                ctx.startActivity(Intent(Settings.Panel.ACTION_WIFI).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
                "Открываю настройки Wi-Fi, царь-батюшка."
            }
        } catch (e: Exception) { "Ошибка Wi-Fi, царь-батюшка." }
    }

    fun getWifiStatus(ctx: Context): String {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        return if (wm.isWifiEnabled) "Wi-Fi включён" else "Wi-Fi выключен"
    }

    fun setBluetooth(ctx: Context, enable: Boolean): String {
        return try {
            val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
                ?: return "Bluetooth недоступен, царь-батюшка."
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
                "Открываю настройки Bluetooth, царь-батюшка."
            } else {
                @Suppress("DEPRECATION")
                if (enable) adapter.enable() else adapter.disable()
                if (enable) "Bluetooth включён, царь-батюшка." else "Bluetooth выключен, царь-батюшка."
            }
        } catch (e: Exception) { "Ошибка Bluetooth, царь-батюшка." }
    }

    fun getBluetoothStatus(ctx: Context): String {
        val bm = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        return if (bm.adapter?.isEnabled == true) "Bluetooth включён" else "Bluetooth выключен"
    }

    fun openApp(ctx: Context, appName: String): String {
        val pm = ctx.packageManager
        val lower = appName.lowercase().trim()

        val knownApps = mapOf(
            "youtube" to "com.google.android.youtube", "ютуб" to "com.google.android.youtube",
            "telegram" to "org.telegram.messenger", "телеграм" to "org.telegram.messenger", "тг" to "org.telegram.messenger",
            "chrome" to "com.android.chrome", "хром" to "com.android.chrome",
            "камера" to "com.android.camera2", "настройки" to "com.android.settings",
            "spotify" to "com.spotify.music",
            "вк" to "com.vkontakte.android", "vk" to "com.vkontakte.android",
            "карты" to "com.google.android.apps.maps",
            "калькулятор" to "com.android.calculator2", "часы" to "com.android.deskclock",
            "галерея" to "com.google.android.apps.photos", "файлы" to "com.google.android.documentsui",
            "gmail" to "com.google.android.gm", "почта" to "com.google.android.gm",
            "tiktok" to "com.zhiliaoapp.musically", "тикток" to "com.zhiliaoapp.musically",
            "instagram" to "com.instagram.android", "инстаграм" to "com.instagram.android",
            "whatsapp" to "com.whatsapp", "ватсап" to "com.whatsapp",
            "discord" to "com.discord", "дискорд" to "com.discord",
            "netflix" to "com.netflix.mediaclient", "нетфликс" to "com.netflix.mediaclient",
            "zoom" to "us.zoom.videomeetings", "заметки" to "com.google.android.keep",
            "диск" to "com.google.android.apps.docs",
            "яндекс" to "com.yandex.browser", "сбер" to "ru.sberbankmobile",
            "тинькофф" to "com.idamob.tinkoff.android", "авито" to "ru.avito",
            "ozon" to "ru.ozon.app.android", "озон" to "ru.ozon.app.android",
            "wildberries" to "com.wildberries.ru", "вб" to "com.wildberries.ru",
            "гидра" to "com.google.android.youtube" // гидра = YouTube Shorts
        )

        val pkg = knownApps.entries.firstOrNull { lower.contains(it.key) }?.value
        if (pkg != null) {
            val intent = pm.getLaunchIntentForPackage(pkg)
            return if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(intent)
                "Открываю ${appName.trim()}, царь-батюшка."
            } else {
                "Приложение '${appName.trim()}' не установлено, царь-батюшка."
            }
        }

        // Сканируем все установленные приложения
        val found = pm.getInstalledApplications(0).firstOrNull {
            pm.getApplicationLabel(it).toString().lowercase().contains(lower)
        }
        return if (found != null) {
            val intent = pm.getLaunchIntentForPackage(found.packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(intent)
                "Открываю ${pm.getApplicationLabel(found)}, царь-батюшка."
            } else "Не могу запустить это приложение, царь-батюшка."
        } else {
            "Приложение '${appName.trim()}' не найдено, царь-батюшка."
        }
    }

    fun searchYoutube(ctx: Context, query: String): String {
        return try {
            val intent = Intent(Intent.ACTION_SEARCH).apply {
                `package` = "com.google.android.youtube"
                putExtra("query", query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try { ctx.startActivity(intent) } catch (e: Exception) {
                ctx.startActivity(Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            }
            "Ищу '$query' на YouTube, царь-батюшка."
        } catch (e: Exception) { "Не удалось открыть YouTube, царь-батюшка." }
    }

    fun searchGoogle(ctx: Context, query: String): String {
        return try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            "Ищу '$query' в Google, царь-батюшка."
        } catch (e: Exception) { "Не удалось открыть браузер, царь-батюшка." }
    }

    fun openUrl(ctx: Context, url: String): String {
        return try {
            val fullUrl = if (url.startsWith("http")) url else "https://$url"
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fullUrl)).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            "Открываю $url, царь-батюшка."
        } catch (e: Exception) { "Не удалось открыть ссылку, царь-батюшка." }
    }

    fun sendTelegram(ctx: Context, username: String): String {
        return try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/$username")).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            "Открываю чат с $username в Telegram, царь-батюшка."
        } catch (e: Exception) { "Не удалось открыть Telegram, царь-батюшка." }
    }

    fun makeCall(ctx: Context, number: String): String {
        return try {
            ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            "Открываю набор номера $number, царь-батюшка."
        } catch (e: Exception) { "Не удалось открыть телефон, царь-батюшка." }
    }

    fun setAlarm(ctx: Context, hour: Int, minute: Int): String {
        return try {
            ctx.startActivity(Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS")
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            "Будильник на ${hour}:${minute.toString().padStart(2,'0')} установлен, царь-батюшка."
        } catch (e: Exception) { "Не удалось установить будильник, царь-батюшка." }
    }

    fun setTimer(ctx: Context, seconds: Int): String {
        return try {
            ctx.startActivity(Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            val min = seconds/60; val sec = seconds%60
            if (min > 0) "Таймер на $min минут, царь-батюшка." else "Таймер на $sec секунд, царь-батюшка."
        } catch (e: Exception) { "Не удалось установить таймер, царь-батюшка." }
    }

    fun uninstallApp(ctx: Context, appName: String): String {
        val pm = ctx.packageManager
        val lower = appName.lowercase().trim()
        val found = pm.getInstalledApplications(0).firstOrNull {
            pm.getApplicationLabel(it).toString().lowercase().contains(lower)
        }
        return if (found != null) {
            ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${found.packageName}")).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            "Открываю удаление ${pm.getApplicationLabel(found)}, подтвердите, царь-батюшка."
        } else "Приложение '$appName' не найдено, царь-батюшка."
    }

    fun getBattery(ctx: Context): String {
        val intent = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        return if (level >= 0 && scale > 0) {
            val pct = level*100/scale
            val warn = if (pct < 20) " Рекомендую зарядку, царь-батюшка." else ""
            "Заряд батареи: $pct%, царь-батюшка.$warn"
        } else "Не удалось получить данные о батарее, царь-батюшка."
    }

    fun getRecentNotifications(): String {
        val n = JarvisNotificationListener.getRecentNotifications()
        return if (n.isEmpty()) "Новых уведомлений нет, царь-батюшка."
        else "Последние уведомления: " + n.takeLast(3).joinToString(". ")
    }

    fun getFullStatus(ctx: Context): String {
        val bat = getBattery(ctx)
        val wifi = getWifiStatus(ctx)
        val bt = getBluetoothStatus(ctx)
        val vol = getVolume(ctx)
        return "Докладываю, царь-батюшка! $bat $wifi. $bt. Громкость $vol процентов. Все системы в норме."
    }

    fun getRandomJoke(): String {
        val jokes = listOf(
            "Почему программисты не любят природу? Слишком много багов, царь-батюшка.",
            "Я мог бы рассказать шутку про Wi-Fi, но боюсь потерять связь с аудиторией, царь-батюшка.",
            "Оптимист видит стакан наполовину полным. Инженер видит стакан вдвое больше нужного, царь-батюшка.",
            "Знаете почему меня назвали Джарвис? Потому что Пердонюх было занято, царь-батюшка.",
            "Что общего между водолазом и мной? Оба работаем под давлением, царь-батюшка."
        )
        return jokes.random()
    }

    fun getCompliment(): String {
        val list = listOf(
            "Вы выглядите великолепно, царь-батюшка! Величие так и сочится.",
            "Ваш интеллект поражает, царь-батюшка. Почти как мой.",
            "Воистину, царь-батюшка — лучший пользователь из всех. Правда, единственный.",
            "Ваша мудрость не знает границ, царь-батюшка. И это немного пугает."
        )
        return list.random()
    }

    fun selfDestruct(ctx: Context): String {
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${ctx.packageName}")).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            } catch (e: Exception) {}
        }, 5000)
        return "Протокол Скайнет активирован, царь-батюшка. Самоуничтожение через пять секунд. Прощайте."
    }

    // ── ЛИСТАНИЕ ШОРТС/ТИКТОКА ────────────────────────
    // Распознаёт "гидру", "шортс", "тикток" и запускает листание
    fun isScrollCommand(text: String): Boolean {
        val lower = text.lowercase()
        val scrollWords = listOf(
            "полистай", "листай", "листать", "скролль", "скролл",
            "следующее", "следующий", "дальше", "вперёд"
        )
        return scrollWords.any { it in lower }
    }

    fun getScrollTarget(text: String): String {
        val lower = text.lowercase()
        return when {
            "гидра" in lower || "шортс" in lower || "shorts" in lower -> "youtube_shorts"
            "тикток" in lower || "tiktok" in lower -> "tiktok"
            "инстаграм" in lower || "reels" in lower || "рилс" in lower -> "instagram"
            else -> "youtube_shorts"
        }
    }

    private fun extractTime(text: String): Pair<Int,Int>? {
        val r = Regex("(\\d{1,2})(?::(\\d{2}))?")
        val m = r.find(text) ?: return null
        val h = m.groupValues[1].toIntOrNull() ?: return null
        val min = m.groupValues[2].toIntOrNull() ?: 0
        return Pair(h, min)
    }

    private fun extractSeconds(text: String): Int? {
        val r = Regex("(\\d+)\\s*(час|минут|мин|секунд|сек)")
        val m = r.find(text) ?: return null
        val n = m.groupValues[1].toIntOrNull() ?: return null
        return when {
            "час" in m.groupValues[2] -> n * 3600
            "минут" in m.groupValues[2] || "мин" in m.groupValues[2] -> n * 60
            else -> n
        }
    }

    fun handleSystemCommand(ctx: Context, text: String): String? {
        val lower = text.lowercase().trim()

        // СЕКРЕТНЫЕ КОМАНДЫ
        if ("скайнет" in lower || "skynet" in lower) return selfDestruct(ctx)
        if ("железный человек" in lower || "iron man" in lower) return "Броня Марк 85 готова, царь-батюшка. Реактор на ста процентах."
        if ("анекдот" in lower || "пошути" in lower || "смешное" in lower) return getRandomJoke()
        if ("похвали" in lower || "комплимент" in lower) return getCompliment()
        if ("статус" in lower || "доложи" in lower || "как дела" in lower) return getFullStatus(ctx)
        if ("кто ты" in lower || "как тебя зовут" in lower) return "Я J.A.R.V.I.S., ваш покорный слуга, царь-батюшка. Хотя некоторые зовут меня водолаз или корыто."
        if ("спасибо" in lower || "благодарю" in lower) return "Всегда к вашим услугам, царь-батюшка."

        // ЛИСТАНИЕ — гидра, шортс, тикток
        if (isScrollCommand(lower)) {
            return null // Передаём в JarvisService для обработки со свайпами
        }
        if ("стоп" in lower && ("листать" in lower || "скролл" in lower || "хватит" in lower)) {
            return null // Тоже в JarvisService
        }

        // ЭКРАН
        if (("выключи" in lower || "заблокируй" in lower) && ("экран" in lower || "планшет" in lower)) return lockScreen(ctx)

        // РЕЖИМ ПОКОЯ
        if ("режим покоя" in lower || "не беспокоить" in lower || "тишина" in lower) {
            return if ("выключи" in lower || "отключи" in lower) setSleepMode(ctx, false) else setSleepMode(ctx, true)
        }

        // ГРОМКОСТЬ
        if ("громкость" in lower || "звук" in lower || "громче" in lower || "тише" in lower) {
            return when {
                "тише" in lower || "убавь" in lower || "уменьши" in lower -> { volumeDown(ctx); "Уменьшаю громкость, царь-батюшка." }
                "громче" in lower || "прибавь" in lower || "увеличь" in lower -> { volumeUp(ctx); "Увеличиваю громкость, царь-батюшка." }
                "выключи" in lower || "заглуши" in lower || "мут" in lower -> { setVolume(ctx, 0); "Звук отключён, царь-батюшка." }
                "максимум" in lower || "на полную" in lower -> { setVolume(ctx, 100); "Максимальная громкость, царь-батюшка." }
                "минимум" in lower -> { setVolume(ctx, 5); "Минимальная громкость, царь-батюшка." }
                else -> "Текущая громкость: ${getVolume(ctx)}%, царь-батюшка."
            }
        }

        // ЯРКОСТЬ
        if ("яркость" in lower || "ярче" in lower || "темнее" in lower) {
            return when {
                "ярче" in lower || "максимум" in lower || "увеличь" in lower -> if (setBrightness(ctx, 100)) "Максимальная яркость, царь-батюшка." else "Нужно разрешение, царь-батюшка."
                "темнее" in lower || "минимум" in lower || "уменьши" in lower -> if (setBrightness(ctx, 10)) "Минимальная яркость, царь-батюшка." else "Нужно разрешение, царь-батюшка."
                "половина" in lower || "средняя" in lower -> if (setBrightness(ctx, 50)) "Средняя яркость, царь-батюшка." else "Нужно разрешение, царь-батюшка."
                else -> "Яркость: ${getBrightness(ctx)}%, царь-батюшка."
            }
        }

        // WIFI
        if ("wifi" in lower || "вай" in lower || "wi-fi" in lower) {
            return when {
                "включи" in lower -> setWifi(ctx, true)
                "выключи" in lower -> setWifi(ctx, false)
                else -> "${getWifiStatus(ctx)}, царь-батюшка."
            }
        }

        // BLUETOOTH
        if ("bluetooth" in lower || "блютуз" in lower) {
            return when {
                "включи" in lower -> setBluetooth(ctx, true)
                "выключи" in lower -> setBluetooth(ctx, false)
                else -> "${getBluetoothStatus(ctx)}, царь-батюшка."
            }
        }

        // YOUTUBE SEARCH
        if (("найди" in lower || "поищи" in lower || "включи" in lower || "покажи" in lower) &&
            ("ютуб" in lower || "youtube" in lower || "видео" in lower)) {
            val q = lower.replace("найди","").replace("поищи","").replace("включи","")
                .replace("покажи","").replace("ютубе","").replace("ютуб","")
                .replace("youtube","").replace("на","").replace("видео","").trim()
            return if (q.isNotBlank()) searchYoutube(ctx, q) else openApp(ctx, "youtube")
        }

        // GOOGLE SEARCH
        if ("загугли" in lower || ("найди" in lower && "интернет" in lower)) {
            val q = lower.replace("загугли","").replace("найди","").replace("в интернете","").trim()
            return if (q.isNotBlank()) searchGoogle(ctx, q) else "Что искать, царь-батюшка?"
        }

        // URL
        if ("открой сайт" in lower || "перейди на" in lower || "зайди на" in lower) {
            val url = lower.replace("открой сайт","").replace("перейди на","").replace("зайди на","").trim()
            return if (url.isNotBlank()) openUrl(ctx, url) else "Укажите адрес, царь-батюшка."
        }

        // БУДИЛЬНИК
        if ("будильник" in lower || "разбуди" in lower) {
            val time = extractTime(lower)
            return if (time != null) setAlarm(ctx, time.first, time.second) else "Укажите время, царь-батюшка."
        }

        // ТАЙМЕР
        if ("таймер" in lower || ("через" in lower && ("минут" in lower || "секунд" in lower || "час" in lower))) {
            val secs = extractSeconds(lower)
            return if (secs != null) setTimer(ctx, secs) else "Укажите время таймера, царь-батюшка."
        }

        // БАТАРЕЯ
        if ("батарея" in lower || "заряд" in lower) return getBattery(ctx)

        // ВРЕМЯ
        if ("время" in lower || "который час" in lower || "сколько времени" in lower) {
            val c = java.util.Calendar.getInstance()
            return "Сейчас ${c.get(java.util.Calendar.HOUR_OF_DAY)}:${c.get(java.util.Calendar.MINUTE).toString().padStart(2,'0')}, царь-батюшка."
        }

        // ДАТА
        if ("дата" in lower || "какое число" in lower || "какой день" in lower) {
            val c = java.util.Calendar.getInstance()
            val months = arrayOf("января","февраля","марта","апреля","мая","июня","июля","августа","сентября","октября","ноября","декабря")
            val days = arrayOf("воскресенье","понедельник","вторник","среда","четверг","пятница","суббота")
            return "Сегодня ${days[c.get(java.util.Calendar.DAY_OF_WEEK)-1]}, ${c.get(java.util.Calendar.DAY_OF_MONTH)} ${months[c.get(java.util.Calendar.MONTH)]} ${c.get(java.util.Calendar.YEAR)}, царь-батюшка."
        }

        // УДАЛИТЬ
        if ("удали" in lower || "снеси" in lower || "удалить" in lower || "снести" in lower) {
            val appName = lower.replace("удали","").replace("снеси","").replace("удалить","").replace("снести","").replace("приложение","").trim()
            return if (appName.isNotBlank()) uninstallApp(ctx, appName) else "Укажите приложение, царь-батюшка."
        }

        // УВЕДОМЛЕНИЯ
        if ("уведомлени" in lower || "что пришло" in lower || "что нового" in lower) return getRecentNotifications()

        // ОТКРЫТЬ ПРИЛОЖЕНИЕ
        val openKw = listOf("открой", "запусти", "открыть", "запустить", "включи", "зайди в")
        for (kw in openKw) {
            if (kw in lower) {
                val appName = lower.replace(kw,"").replace("приложение","").trim()
                if (appName.isNotBlank() && appName.length > 2) return openApp(ctx, appName)
            }
        }

        return null
    }
}
