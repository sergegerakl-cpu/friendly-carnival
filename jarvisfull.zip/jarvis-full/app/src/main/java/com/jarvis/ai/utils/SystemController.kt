package com.jarvis.ai.utils

import android.app.NotificationManager
import android.bluetooth.BluetoothManager
import android.content.*
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import com.jarvis.ai.service.JarvisNotificationListener

object SystemController {

    // ── VOLUME ─────────────────────────────────────────
    fun setVolume(ctx: Context, level: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.setStreamVolume(AudioManager.STREAM_MUSIC, level.coerceIn(0,100)*am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)/100, AudioManager.FLAG_SHOW_UI)
    }
    fun getVolume(ctx: Context): Int {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.getStreamVolume(AudioManager.STREAM_MUSIC)*100/am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    }
    fun volumeUp(ctx: Context) = (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
    fun volumeDown(ctx: Context) = (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)

    // ── BRIGHTNESS ─────────────────────────────────────
    fun setBrightness(ctx: Context, level: Int): Boolean = try {
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, level.coerceIn(0,100)*255/100); true
    } catch (e: Exception) { false }
    fun getBrightness(ctx: Context) = try { Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS)*100/255 } catch(e:Exception){-1}

    // ── SCREEN LOCK ────────────────────────────────────
    fun lockScreen(ctx: Context): String = try {
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
        dpm.lockNow(); "Экран заблокирован, сэр."
    } catch (e: Exception) { "Требуются права администратора, сэр." }

    // ── DO NOT DISTURB ─────────────────────────────────
    fun setSleepMode(ctx: Context, enable: Boolean): String = try {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(if (enable) NotificationManager.INTERRUPTION_FILTER_NONE else NotificationManager.INTERRUPTION_FILTER_ALL)
            if (enable) "Режим покоя активирован, сэр." else "Режим покоя отключён, сэр."
        } else {
            ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            "Разрешите доступ в настройках, сэр."
        }
    } catch (e: Exception) { "Ошибка режима покоя, сэр." }

    // ── WIFI ───────────────────────────────────────────
    @Suppress("DEPRECATION")
    fun setWifi(ctx: Context, enable: Boolean): String = try {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled = enable
            if (enable) "Wi-Fi включён, сэр." else "Wi-Fi выключен, сэр."
        } else {
            ctx.startActivity(Intent(Settings.Panel.ACTION_WIFI).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            "Открываю настройки Wi-Fi, сэр."
        }
    } catch (e: Exception) { "Ошибка Wi-Fi, сэр." }
    fun getWifiStatus(ctx: Context) = if ((ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled) "Wi-Fi включён" else "Wi-Fi выключен"

    // ── BLUETOOTH ──────────────────────────────────────
    fun setBluetooth(ctx: Context, enable: Boolean): String = try {
        val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter ?: return "Bluetooth недоступен, сэр."
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }); "Открываю настройки Bluetooth, сэр."
        } else {
            @Suppress("DEPRECATION") if (enable) adapter.enable() else adapter.disable()
            if (enable) "Bluetooth включён, сэр." else "Bluetooth выключен, сэр."
        }
    } catch (e: Exception) { "Ошибка Bluetooth, сэр." }
    fun getBluetoothStatus(ctx: Context) = if ((ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.isEnabled == true) "Bluetooth включён" else "Bluetooth выключен"

    // ── OPEN APP ───────────────────────────────────────
    fun openApp(ctx: Context, appName: String): String {
        val pm = ctx.packageManager
        val lower = appName.lowercase().trim()
        val knownApps = mapOf(
            "youtube" to "com.google.android.youtube", "ютуб" to "com.google.android.youtube",
            "telegram" to "org.telegram.messenger", "телеграм" to "org.telegram.messenger",
            "chrome" to "com.android.chrome", "хром" to "com.android.chrome",
            "камера" to "com.android.camera2", "camera" to "com.android.camera2",
            "настройки" to "com.android.settings", "settings" to "com.android.settings",
            "spotify" to "com.spotify.music", "вк" to "com.vkontakte.android", "vk" to "com.vkontakte.android",
            "карты" to "com.google.android.apps.maps", "maps" to "com.google.android.apps.maps",
            "калькулятор" to "com.android.calculator2", "calculator" to "com.android.calculator2",
            "часы" to "com.android.deskclock", "галерея" to "com.google.android.apps.photos",
            "файлы" to "com.google.android.documentsui", "gmail" to "com.google.android.gm",
            "почта" to "com.google.android.gm", "tiktok" to "com.zhiliaoapp.musically",
            "тикток" to "com.zhiliaoapp.musically", "instagram" to "com.instagram.android",
            "инстаграм" to "com.instagram.android", "whatsapp" to "com.whatsapp", "ватсап" to "com.whatsapp",
            "музыка" to "com.google.android.music", "браузер" to "com.android.browser",
            "заметки" to "com.google.android.keep", "keep" to "com.google.android.keep",
            "диск" to "com.google.android.apps.docs", "drive" to "com.google.android.apps.docs",
            "zoom" to "us.zoom.videomeetings", "зум" to "us.zoom.videomeetings",
            "discord" to "com.discord", "дискорд" to "com.discord",
            "netflix" to "com.netflix.mediaclient", "нетфликс" to "com.netflix.mediaclient"
        )
        val pkg = knownApps.entries.firstOrNull { lower.contains(it.key) }?.value
        if (pkg != null) {
            val intent = pm.getLaunchIntentForPackage(pkg)
            return if (intent != null) { intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(intent); "Открываю ${appName.trim()}, сэр." }
            else "Приложение '${appName.trim()}' не установлено на устройстве, сэр."
        }
        val found = pm.getInstalledApplications(0).firstOrNull { pm.getApplicationLabel(it).toString().lowercase().contains(lower) }
        return if (found != null) {
            val intent = pm.getLaunchIntentForPackage(found.packageName)
            if (intent != null) { intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(intent); "Открываю ${pm.getApplicationLabel(found)}, сэр." }
            else "Не могу запустить это приложение, сэр."
        } else "Приложение '${appName.trim()}' не найдено на устройстве, сэр."
    }

    // ── YOUTUBE SEARCH ─────────────────────────────────
    fun searchYoutube(ctx: Context, query: String): String {
        return try {
            val intent = Intent(Intent.ACTION_SEARCH).apply {
                `package` = "com.google.android.youtube"
                putExtra("query", query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                ctx.startActivity(intent)
            } catch (e: Exception) {
                // Fallback to browser
                val uri = Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
                ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            }
            "Ищу '$query' на YouTube, сэр."
        } catch (e: Exception) { "Не удалось открыть YouTube, сэр." }
    }

    // ── GOOGLE SEARCH ──────────────────────────────────
    fun searchGoogle(ctx: Context, query: String): String {
        return try {
            val uri = Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")
            ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            "Ищу '$query' в Google, сэр."
        } catch (e: Exception) { "Не удалось открыть браузер, сэр." }
    }

    // ── CALL ───────────────────────────────────────────
    fun makeCall(ctx: Context, number: String): String {
        return try {
            val uri = Uri.parse("tel:$number")
            ctx.startActivity(Intent(Intent.ACTION_DIAL, uri).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            "Открываю набор номера $number, сэр."
        } catch (e: Exception) { "Не удалось открыть телефон, сэр." }
    }

    // ── SMS ────────────────────────────────────────────
    fun sendSms(ctx: Context, number: String, text: String = ""): String {
        return try {
            val uri = Uri.parse("smsto:$number")
            val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
                putExtra("sms_body", text)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(intent)
            "Открываю сообщение для $number, сэр."
        } catch (e: Exception) { "Не удалось открыть SMS, сэр." }
    }

    // ── ALARM ──────────────────────────────────────────
    fun setAlarm(ctx: Context, hour: Int, minute: Int, label: String = "JARVIS"): String {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, label)
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(intent)
            "Будильник установлен на ${hour}:${minute.toString().padStart(2,'0')}, сэр."
        } catch (e: Exception) { "Не удалось установить будильник, сэр." }
    }

    // ── TIMER ──────────────────────────────────────────
    fun setTimer(ctx: Context, seconds: Int): String {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(intent)
            val min = seconds / 60; val sec = seconds % 60
            if (min > 0) "Таймер на $min минут установлен, сэр." else "Таймер на $sec секунд установлен, сэр."
        } catch (e: Exception) { "Не удалось установить таймер, сэр." }
    }

    // ── OPEN URL ───────────────────────────────────────
    fun openUrl(ctx: Context, url: String): String {
        return try {
            val fullUrl = if (url.startsWith("http")) url else "https://$url"
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fullUrl)).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            "Открываю $url, сэр."
        } catch (e: Exception) { "Не удалось открыть ссылку, сэр." }
    }

    // ── UNINSTALL APP ──────────────────────────────────
    fun uninstallApp(ctx: Context, appName: String): String {
        val pm = ctx.packageManager
        val lower = appName.lowercase().trim()
        val found = pm.getInstalledApplications(0).firstOrNull { pm.getApplicationLabel(it).toString().lowercase().contains(lower) }
        return if (found != null) {
            ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${found.packageName}")).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            "Открываю удаление ${pm.getApplicationLabel(found)}, сэр. Подтвердите удаление."
        } else "Приложение '$appName' не найдено, сэр."
    }

    // ── NOTIFICATIONS ──────────────────────────────────
    fun getRecentNotifications(): String {
        val n = JarvisNotificationListener.getRecentNotifications()
        return if (n.isEmpty()) "Новых уведомлений нет, сэр." else "Последние уведомления: " + n.takeLast(3).joinToString(". ")
    }

    // ── BATTERY ────────────────────────────────────────
    fun getBattery(ctx: Context): String {
        val i = ctx.registerReceiver(null, IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
        val l = i?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val s = i?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1) ?: -1
        return if (l>=0&&s>0) "Заряд батареи: ${l*100/s}%, сэр." else "Не удалось получить данные о батарее, сэр."
    }

    // ── SELF DESTRUCT ──────────────────────────────────
    fun selfDestruct(ctx: Context): String {
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            try {
                ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${ctx.packageName}")).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            } catch (e: Exception) {}
        }, 5000)
        return "Протокол Скайнет активирован. Самоуничтожение через пять секунд. Было честью служить вам, сэр. Прощайте."
    }

    // ── PARSE NUMBER FROM TEXT ─────────────────────────
    private fun extractNumber(text: String): String {
        return text.replace(Regex("[^0-9+]"), "").trim()
    }

    private fun extractTime(text: String): Pair<Int,Int>? {
        val r = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(?:час|утра|вечера|ночи|:)?")
        val m = r.find(text) ?: return null
        val h = m.groupValues[1].toIntOrNull() ?: return null
        val min = m.groupValues[2].toIntOrNull() ?: 0
        return Pair(h, min)
    }

    private fun extractMinutes(text: String): Int? {
        val r = Regex("(\\d+)\\s*(?:минут|мин|секунд|сек)")
        val m = r.find(text) ?: return null
        val n = m.groupValues[1].toIntOrNull() ?: return null
        return if ("секунд" in text || "сек" in text) n else n * 60
    }

    // ── MAIN COMMAND PARSER ────────────────────────────
    fun handleSystemCommand(ctx: Context, text: String): String? {
        val lower = text.lowercase().trim()

        // SKYNET
        if ("скайнет" in lower || "skynet" in lower) return selfDestruct(ctx)

        // SCREEN LOCK
        if (("выключи" in lower || "заблокируй" in lower) && ("экран" in lower || "дисплей" in lower || "планшет" in lower))
            return lockScreen(ctx)

        // SLEEP MODE
        if ("режим покоя" in lower || "не беспокоить" in lower || "тихий режим" in lower)
            return when { "включи" in lower || "активируй" in lower -> setSleepMode(ctx, true); "выключи" in lower || "отключи" in lower -> setSleepMode(ctx, false); else -> setSleepMode(ctx, true) }

        // VOLUME
        if ("громкость" in lower || "звук" in lower)
            return when {
                "тише" in lower || "убавь" in lower || "уменьши" in lower -> { volumeDown(ctx); "Уменьшаю громкость, сэр." }
                "громче" in lower || "прибавь" in lower || "увеличь" in lower -> { volumeUp(ctx); "Увеличиваю громкость, сэр." }
                "выключи" in lower || "заглуши" in lower || "мут" in lower -> { setVolume(ctx,0); "Звук отключён, сэр." }
                "максимум" in lower || "максимальная" in lower -> { setVolume(ctx,100); "Максимальная громкость, сэр." }
                "минимум" in lower || "минимальная" in lower -> { setVolume(ctx,5); "Минимальная громкость, сэр." }
                else -> "Текущая громкость: ${getVolume(ctx)}%, сэр."
            }

        // BRIGHTNESS
        if ("яркость" in lower || ("экран" in lower && ("ярче" in lower || "темнее" in lower)))
            return when {
                "увеличь" in lower || "ярче" in lower || "максимум" in lower -> if (setBrightness(ctx,100)) "Максимальная яркость, сэр." else "Нужно разрешение, сэр."
                "уменьши" in lower || "темнее" in lower || "минимум" in lower -> if (setBrightness(ctx,10)) "Минимальная яркость, сэр." else "Нужно разрешение, сэр."
                else -> "Яркость: ${getBrightness(ctx)}%, сэр."
            }

        // WIFI
        if ("wifi" in lower || "вай" in lower || "wi-fi" in lower)
            return when { "включи" in lower -> setWifi(ctx, true); "выключи" in lower -> setWifi(ctx, false); else -> "${getWifiStatus(ctx)}, сэр." }

        // BLUETOOTH
        if ("bluetooth" in lower || "блютуз" in lower || "блютус" in lower)
            return when { "включи" in lower -> setBluetooth(ctx, true); "выключи" in lower -> setBluetooth(ctx, false); else -> "${getBluetoothStatus(ctx)}, сэр." }

        // YOUTUBE SEARCH
        if (("найди" in lower || "поищи" in lower || "включи" in lower || "поставь" in lower) && ("ютуб" in lower || "youtube" in lower)) {
            val query = lower.replace("найди","").replace("поищи","").replace("включи","").replace("поставь","")
                .replace("ютубе","").replace("ютуб","").replace("youtube","").replace("на","").trim()
            return if (query.isNotBlank()) searchYoutube(ctx, query) else { openApp(ctx, "youtube") }
        }

        // GOOGLE SEARCH
        if (("найди" in lower || "поищи" in lower || "загугли" in lower || "поиск" in lower) && ("гугл" in lower || "google" in lower || "интернет" in lower)) {
            val query = lower.replace("найди","").replace("поищи","").replace("загугли","").replace("поиск","")
                .replace("гугл","").replace("google","").replace("в интернете","").replace("интернет","").trim()
            return if (query.isNotBlank()) searchGoogle(ctx, query) else "Что искать, сэр?"
        }

        // OPEN URL
        if ("открой сайт" in lower || "перейди на" in lower || "зайди на" in lower) {
            val url = lower.replace("открой сайт","").replace("перейди на","").replace("зайди на","").trim()
            return if (url.isNotBlank()) openUrl(ctx, url) else "Укажите адрес сайта, сэр."
        }

        // CALL
        if ("позвони" in lower || "набери" in lower || "вызови" in lower) {
            val num = extractNumber(lower)
            return if (num.isNotBlank()) makeCall(ctx, num) else "Укажите номер телефона, сэр."
        }

        // SMS
        if ("напиши" in lower || "отправь" in lower || "сообщение" in lower) {
            val num = extractNumber(lower)
            return if (num.isNotBlank()) sendSms(ctx, num) else "Укажите номер для сообщения, сэр."
        }

        // ALARM
        if ("будильник" in lower || "разбуди" in lower) {
            val time = extractTime(lower)
            return if (time != null) setAlarm(ctx, time.first, time.second)
            else "Укажите время для будильника, сэр."
        }

        // TIMER
        if ("таймер" in lower || "через" in lower && ("минут" in lower || "секунд" in lower)) {
            val secs = extractMinutes(lower)
            return if (secs != null) setTimer(ctx, secs) else "Укажите время таймера, сэр."
        }

        // BATTERY
        if ("батарея" in lower || "заряд" in lower) return getBattery(ctx)

        // TIME
        if ("время" in lower || "который час" in lower || "сколько времени" in lower) {
            val c = java.util.Calendar.getInstance()
            return "Сейчас ${c.get(java.util.Calendar.HOUR_OF_DAY)}:${c.get(java.util.Calendar.MINUTE).toString().padStart(2,'0')}, сэр."
        }

        // DATE
        if ("дата" in lower || "какое число" in lower || "какой день" in lower) {
            val c = java.util.Calendar.getInstance()
            val months = arrayOf("января","февраля","марта","апреля","мая","июня","июля","августа","сентября","октября","ноября","декабря")
            val days = arrayOf("воскресенье","понедельник","вторник","среда","четверг","пятница","суббота")
            return "Сегодня ${days[c.get(java.util.Calendar.DAY_OF_WEEK)-1]}, ${c.get(java.util.Calendar.DAY_OF_MONTH)} ${months[c.get(java.util.Calendar.MONTH)]} ${c.get(java.util.Calendar.YEAR)} года, сэр."
        }

        // UNINSTALL
        if ("удали" in lower || "снеси" in lower || "удалить" in lower || "снести" in lower) {
            val appName = lower.replace("удали","").replace("снеси","").replace("удалить","").replace("снести","")
                .replace("приложение","").trim()
            return if (appName.isNotBlank()) uninstallApp(ctx, appName) else "Укажите приложение для удаления, сэр."
        }

        // NOTIFICATIONS
        if ("уведомлени" in lower || "что пришло" in lower || "что нового" in lower) return getRecentNotifications()

        // OPEN APP
        if ("открой" in lower || "запусти" in lower || "открыть" in lower || "запустить" in lower) {
            val appName = lower.replace("открой","").replace("открыть","").replace("запусти","").replace("запустить","")
                .replace("приложение","").trim()
            if (appName.isNotBlank()) return openApp(ctx, appName)
        }

        return null // pass to AI
    }
}
