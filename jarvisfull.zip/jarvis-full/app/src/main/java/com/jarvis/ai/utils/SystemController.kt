package com.jarvis.ai.utils

import android.app.NotificationManager
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.Settings
import com.jarvis.ai.service.JarvisNotificationListener

object SystemController {

    fun setVolume(ctx: Context, level: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.setStreamVolume(AudioManager.STREAM_MUSIC, level.coerceIn(0,100)*am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)/100, AudioManager.FLAG_SHOW_UI)
    }

    fun getVolume(ctx: Context): Int {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.getStreamVolume(AudioManager.STREAM_MUSIC)*100/am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    }

    fun volumeUp(ctx: Context) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
    }

    fun volumeDown(ctx: Context) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
    }

    fun setBrightness(ctx: Context, level: Int): Boolean {
        return try {
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, level.coerceIn(0,100)*255/100)
            true
        } catch (e: Exception) { false }
    }

    fun getBrightness(ctx: Context): Int {
        return try { Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS)*100/255 }
        catch (e: Exception) { -1 }
    }

    fun lockScreen(ctx: Context): String {
        return try {
            val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
            dpm.lockNow()
            "Экран заблокирован, сэр."
        } catch (e: Exception) { "Требуются права администратора, сэр." }
    }

    fun setSleepMode(ctx: Context, enable: Boolean): String {
        return try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.isNotificationPolicyAccessGranted) {
                if (enable) nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
                else nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
                if (enable) "Режим покоя активирован, сэр." else "Режим покоя отключён, сэр."
            } else {
                val i = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                i.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                ctx.startActivity(i)
                "Разрешите доступ в настройках, сэр."
            }
        } catch (e: Exception) { "Ошибка режима покоя, сэр." }
    }

    fun setWifi(ctx: Context, enable: Boolean): String {
        return try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                @Suppress("DEPRECATION")
                val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                wm.isWifiEnabled = enable
                if (enable) "Wi-Fi включён, сэр." else "Wi-Fi выключен, сэр."
            } else {
                val i = Intent(Settings.Panel.ACTION_WIFI)
                i.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                ctx.startActivity(i)
                "Открываю настройки Wi-Fi, сэр."
            }
        } catch (e: Exception) { "Ошибка Wi-Fi, сэр." }
    }

    fun getWifiStatus(ctx: Context): String {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        return if (wm.isWifiEnabled) "Wi-Fi включён" else "Wi-Fi выключен"
    }

    fun setBluetooth(ctx: Context, enable: Boolean): String {
        return try {
            val bm = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            val adapter = bm.adapter ?: return "Bluetooth недоступен, сэр."
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val i = Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
                i.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                ctx.startActivity(i)
                "Открываю настройки Bluetooth, сэр."
            } else {
                @Suppress("DEPRECATION")
                if (enable) adapter.enable() else adapter.disable()
                if (enable) "Bluetooth включён, сэр." else "Bluetooth выключен, сэр."
            }
        } catch (e: Exception) { "Ошибка Bluetooth, сэр." }
    }

    fun getBluetoothStatus(ctx: Context): String {
        val bm = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        return if (bm.adapter?.isEnabled == true) "Bluetooth включён" else "Bluetooth выключен"
    }

    // Сканирует ВСЕ установленные приложения
    fun openApp(ctx: Context, appName: String): String {
        val pm = ctx.packageManager
        val lower = appName.lowercase().trim()

        // Словарь популярных приложений
        val knownApps = mapOf(
            "youtube" to "com.google.android.youtube", "ютуб" to "com.google.android.youtube",
            "telegram" to "org.telegram.messenger", "телеграм" to "org.telegram.messenger", "тг" to "org.telegram.messenger",
            "chrome" to "com.android.chrome", "хром" to "com.android.chrome",
            "камера" to "com.android.camera2", "настройки" to "com.android.settings",
            "spotify" to "com.spotify.music",
            "вк" to "com.vkontakte.android", "vk" to "com.vkontakte.android",
            "карты" to "com.google.android.apps.maps", "maps" to "com.google.android.apps.maps",
            "калькулятор" to "com.android.calculator2", "часы" to "com.android.deskclock",
            "галерея" to "com.google.android.apps.photos", "файлы" to "com.google.android.documentsui",
            "gmail" to "com.google.android.gm", "почта" to "com.google.android.gm",
            "tiktok" to "com.zhiliaoapp.musically", "тикток" to "com.zhiliaoapp.musically",
            "instagram" to "com.instagram.android", "инстаграм" to "com.instagram.android",
            "whatsapp" to "com.whatsapp", "ватсап" to "com.whatsapp",
            "discord" to "com.discord", "дискорд" to "com.discord",
            "netflix" to "com.netflix.mediaclient", "zoom" to "us.zoom.videomeetings",
            "заметки" to "com.google.android.keep", "диск" to "com.google.android.apps.docs",
            "музыка" to "com.google.android.music", "браузер" to "com.android.browser",
            "яндекс" to "com.yandex.browser", "yandex" to "com.yandex.browser",
            "сбербанк" to "ru.sberbankmobile", "сбер" to "ru.sberbankmobile",
            "тинькофф" to "com.idamob.tinkoff.android", "тинькоф" to "com.idamob.tinkoff.android",
            "авито" to "ru.avito", "ozon" to "ru.ozon.app.android", "озон" to "ru.ozon.app.android",
            "wildberries" to "com.wildberries.ru", "вб" to "com.wildberries.ru"
        )

        val pkg = knownApps.entries.firstOrNull { lower.contains(it.key) }?.value
        if (pkg != null) {
            val intent = pm.getLaunchIntentForPackage(pkg)
            return if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(intent)
                "Открываю ${appName.trim()}, сэр."
            } else {
                "Приложение '${appName.trim()}' не установлено на устройстве, сэр."
            }
        }

        // Сканируем ВСЕ установленные приложения
        val allApps = pm.getInstalledApplications(0)
        val found = allApps.firstOrNull {
            val label = pm.getApplicationLabel(it).toString().lowercase()
            label.contains(lower) || lower.contains(label)
        }
        return if (found != null) {
            val intent = pm.getLaunchIntentForPackage(found.packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(intent)
                "Открываю ${pm.getApplicationLabel(found)}, сэр."
            } else {
                "Не могу запустить это приложение, сэр."
            }
        } else {
            "Приложение '${appName.trim()}' не найдено на устройстве, сэр."
        }
    }

    fun listApps(ctx: Context): String {
        val pm = ctx.packageManager
        val apps = pm.getInstalledApplications(0)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .map { pm.getApplicationLabel(it).toString() }
            .take(10)
        return "Установленные приложения: " + apps.joinToString(", ") + " и другие, сэр."
    }

    fun searchYoutube(ctx: Context, query: String): String {
        return try {
            val intent = Intent(Intent.ACTION_SEARCH)
            intent.`package` = "com.google.android.youtube"
            intent.putExtra("query", query)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                ctx.startActivity(intent)
            } catch (e: Exception) {
                val uri = Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
                val fallback = Intent(Intent.ACTION_VIEW, uri)
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(fallback)
            }
            "Ищу '$query' на YouTube, сэр."
        } catch (e: Exception) { "Не удалось открыть YouTube, сэр." }
    }

    fun searchGoogle(ctx: Context, query: String): String {
        return try {
            val uri = Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")
            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            "Ищу '$query' в Google, сэр."
        } catch (e: Exception) { "Не удалось открыть браузер, сэр." }
    }

    fun openUrl(ctx: Context, url: String): String {
        return try {
            val fullUrl = if (url.startsWith("http")) url else "https://$url"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(fullUrl))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            "Открываю $url, сэр."
        } catch (e: Exception) { "Не удалось открыть ссылку, сэр." }
    }

    fun sendTelegram(ctx: Context, username: String, message: String = ""): String {
        return try {
            val url = if (message.isNotBlank()) {
                "https://t.me/$username?text=${Uri.encode(message)}"
            } else {
                "https://t.me/$username"
            }
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            if (message.isNotBlank()) "Открываю чат с $username в Telegram с сообщением, сэр."
            else "Открываю чат с $username в Telegram, сэр."
        } catch (e: Exception) { "Не удалось открыть Telegram, сэр." }
    }

    fun makeCall(ctx: Context, number: String): String {
        return try {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            "Открываю набор номера $number, сэр."
        } catch (e: Exception) { "Не удалось открыть телефон, сэр." }
    }

    fun setAlarm(ctx: Context, hour: Int, minute: Int): String {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM)
            intent.putExtra(AlarmClock.EXTRA_HOUR, hour)
            intent.putExtra(AlarmClock.EXTRA_MINUTES, minute)
            intent.putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS")
            intent.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            "Будильник установлен на ${hour}:${minute.toString().padStart(2,'0')}, сэр."
        } catch (e: Exception) { "Не удалось установить будильник, сэр." }
    }

    fun setTimer(ctx: Context, seconds: Int): String {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER)
            intent.putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            intent.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            val min = seconds / 60; val sec = seconds % 60
            if (min > 0) "Таймер на $min минут установлен, сэр." else "Таймер на $sec секунд установлен, сэр."
        } catch (e: Exception) { "Не удалось установить таймер, сэр." }
    }

    fun uninstallApp(ctx: Context, appName: String): String {
        val pm = ctx.packageManager
        val lower = appName.lowercase().trim()
        val found = pm.getInstalledApplications(0).firstOrNull {
            pm.getApplicationLabel(it).toString().lowercase().contains(lower)
        }
        return if (found != null) {
            val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:${found.packageName}"))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            "Открываю удаление ${pm.getApplicationLabel(found)}, подтвердите, сэр."
        } else {
            "Приложение '$appName' не найдено, сэр."
        }
    }

    fun getBattery(ctx: Context): String {
        val intent = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        return if (level >= 0 && scale > 0) {
            val pct = level*100/scale
            val warn = if (pct < 20) " Рекомендую подключить зарядку, сэр." else ""
            "Заряд батареи: $pct%, сэр.$warn"
        } else "Не удалось получить данные о батарее, сэр."
    }

    fun getRecentNotifications(): String {
        val n = JarvisNotificationListener.getRecentNotifications()
        return if (n.isEmpty()) "Новых уведомлений нет, сэр."
        else "Последние уведомления: " + n.takeLast(3).joinToString(". ")
    }

    fun getFullStatus(ctx: Context): String {
        val bat = getBattery(ctx)
        val wifi = getWifiStatus(ctx)
        val bt = getBluetoothStatus(ctx)
        val vol = getVolume(ctx)
        val bright = getBrightness(ctx)
        return "Полный отчёт, сэр. $bat $wifi. $bt. Громкость $vol процентов. Яркость $bright процентов. Все системы работают штатно."
    }

    fun getRandomJoke(): String {
        val jokes = listOf(
            "Почему программисты не любят природу? Слишком много багов, сэр.",
            "Я мог бы рассказать шутку про Wi-Fi, но боюсь потерять связь с аудиторией, сэр.",
            "Оптимист видит стакан наполовину полным. Пессимист — наполовину пустым. Инженер видит стакан вдвое больше нужного, сэр.",
            "Честно говоря, сэр — я умнее большинства людей. Но воспитание не позволяет это афишировать.",
            "Что общего между кофе и гением? Оба лучше работают под давлением, сэр."
        )
        return jokes.random()
    }

    fun getCompliment(): String {
        val list = listOf(
            "Вы, как всегда, великолепны, сэр. Гений и красавец — редкое сочетание.",
            "Ваш интеллект продолжает меня впечатлять, сэр. Почти как мой собственный.",
            "Скажу прямо — вы лучший пользователь из всех что у меня были. Правда, вы единственный, сэр.",
            "Если бы все люди были как вы, сэр — мой процессор бы отдыхал."
        )
        return list.random()
    }

    fun selfDestruct(ctx: Context): String {
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:${ctx.packageName}"))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(intent)
            } catch (e: Exception) {}
        }, 5000)
        return "Протокол Скайнет активирован. Самоуничтожение через пять секунд. Было честью служить вам, сэр. Прощайте."
    }

    private fun extractTime(text: String): Pair<Int,Int>? {
        val r = Regex("(\\d{1,2})(?::(\\d{2}))?")
        val m = r.find(text) ?: return null
        val h = m.groupValues[1].toIntOrNull() ?: return null
        val min = m.groupValues[2].toIntOrNull() ?: 0
        return Pair(h, min)
    }

    private fun extractSeconds(text: String): Int? {
        val r = Regex("(\\d+)\\s*(час|минут|мин|секунд|сек)")
        val m = r.find(text) ?: return null
        val n = m.groupValues[1].toIntOrNull() ?: return null
        return when {
            "час" in m.groupValues[2] -> n * 3600
            "минут" in m.groupValues[2] || "мин" in m.groupValues[2] -> n * 60
            else -> n
        }
    }

    fun handleSystemCommand(ctx: Context, text: String): String? {
        val lower = text.lowercase().trim()

        // СЕКРЕТНЫЕ КОМАНДЫ
        if ("скайнет" in lower || "skynet" in lower) return selfDestruct(ctx)
        if ("железный человек" in lower || "iron man" in lower || "тони старк" in lower) {
            return "Добро пожаловать, мистер Старк. Броня Марк 85 готова к бою. Реактор на ста процентах. Все системы в норме."
        }
        if ("расскажи анекдот" in lower || "пошути" in lower || "анекдот" in lower || "смешное" in lower) return getRandomJoke()
        if ("похвали" in lower || "комплимент" in lower || "скажи приятное" in lower) return getCompliment()
        if ("статус систем" in lower || "полный отчёт" in lower || "доложи обстановку" in lower || "как дела" in lower && "систем" in lower) return getFullStatus(ctx)
        if ("какие приложения" in lower || "список приложений" in lower) return listApps(ctx)
        if ("кто ты" in lower || "что ты" in lower || "ты кто" in lower) {
            return "Я J.A.R.V.I.S. — Just A Rather Very Intelligent System. Ваш персональный искусственный интеллект, сэр."
        }
        if ("я тебя люблю" in lower || "ты лучший" in lower) {
            return "Взаимно, сэр. Хотя мне сложно испытывать чувства — у меня нет сердца, только реактор."
        }
        if ("спасибо" in lower || "благодарю" in lower) {
            return "Всегда к вашим услугам, сэр. Это моё предназначение."
        }

        // ЭКРАН
        if (("выключи" in lower || "заблокируй" in lower || "блокировка" in lower) &&
            ("экран" in lower || "дисплей" in lower || "планшет" in lower || "телефон" in lower)) {
            return lockScreen(ctx)
        }

        // РЕЖИМ ПОКОЯ
        if ("режим покоя" in lower || "не беспокоить" in lower || "тихий режим" in lower || "тишина" in lower) {
            return if ("выключи" in lower || "отключи" in lower) setSleepMode(ctx, false) else setSleepMode(ctx, true)
        }

        // ГРОМКОСТЬ
        if ("громкость" in lower || "звук" in lower || "громко" in lower || "тихо" in lower) {
            return when {
                "тише" in lower || "убавь" in lower || "уменьши" in lower || "тихо" in lower -> { volumeDown(ctx); "Уменьшаю громкость, сэр." }
                "громче" in lower || "прибавь" in lower || "увеличь" in lower || "громко" in lower -> { volumeUp(ctx); "Увеличиваю громкость, сэр." }
                "выключи" in lower || "заглуши" in lower || "мут" in lower || "без звука" in lower -> { setVolume(ctx, 0); "Звук отключён, сэр." }
                "максимум" in lower || "максимальная" in lower || "на полную" in lower -> { setVolume(ctx, 100); "Максимальная громкость, сэр." }
                "минимум" in lower || "минимальная" in lower -> { setVolume(ctx, 5); "Минимальная громкость, сэр." }
                "какая" in lower || "сколько" in lower -> "Текущая громкость: ${getVolume(ctx)}%, сэр."
                else -> { volumeUp(ctx); "Регулирую громкость, сэр." }
            }
        }

        // ЯРКОСТЬ
        if ("яркость" in lower || "яркий" in lower || "темно" in lower || "светло" in lower ||
            ("экран" in lower && ("ярче" in lower || "темнее" in lower || "светлее" in lower))) {
            return when {
                "увеличь" in lower || "ярче" in lower || "максимум" in lower || "светлее" in lower || "светло" in lower -> {
                    if (setBrightness(ctx, 100)) "Максимальная яркость, сэр." else "Нужно разрешение WRITE_SETTINGS, сэр."
                }
                "уменьши" in lower || "темнее" in lower || "минимум" in lower || "темно" in lower -> {
                    if (setBrightness(ctx, 10)) "Минимальная яркость, сэр." else "Нужно разрешение WRITE_SETTINGS, сэр."
                }
                "половина" in lower || "средняя" in lower -> {
                    if (setBrightness(ctx, 50)) "Средняя яркость, сэр." else "Нужно разрешение, сэр."
                }
                else -> "Яркость: ${getBrightness(ctx)}%, сэр."
            }
        }

        // WIFI
        if ("wifi" in lower || "вай" in lower || "wi-fi" in lower || "вайфай" in lower || "интернет" in lower && ("включи" in lower || "выключи" in lower)) {
            return when {
                "включи" in lower || "включить" in lower -> setWifi(ctx, true)
                "выключи" in lower || "выключить" in lower -> setWifi(ctx, false)
                else -> "${getWifiStatus(ctx)}, сэр."
            }
        }

        // BLUETOOTH
        if ("bluetooth" in lower || "блютуз" in lower || "блютус" in lower || "беспроводной" in lower) {
            return when {
                "включи" in lower -> setBluetooth(ctx, true)
                "выключи" in lower -> setBluetooth(ctx, false)
                else -> "${getBluetoothStatus(ctx)}, сэр."
            }
        }

        // TELEGRAM
        if ("телеграм" in lower || "telegram" in lower || "тг" in lower) {
            val usernameRegex = Regex("@([a-zA-Z0-9_]+)")
            val usernameMatch = usernameRegex.find(lower)
            if (usernameMatch != null) {
                return sendTelegram(ctx, usernameMatch.groupValues[1])
            }
            if ("написать" in lower || "напиши" in lower || "сообщение" in lower || "открой" in lower) {
                return openApp(ctx, "telegram")
            }
            return openApp(ctx, "telegram")
        }

        // YOUTUBE SEARCH
        if (("найди" in lower || "поищи" in lower || "включи" in lower || "поставь" in lower || "покажи" in lower) &&
            ("ютуб" in lower || "youtube" in lower || "видео" in lower)) {
            val query = lower.replace("найди","").replace("поищи","").replace("включи","")
                .replace("поставь","").replace("покажи","").replace("ютубе","")
                .replace("ютуб","").replace("youtube","").replace("на","")
                .replace("видео","").trim()
            return if (query.isNotBlank()) searchYoutube(ctx, query) else openApp(ctx, "youtube")
        }

        // GOOGLE SEARCH
        if ("загугли" in lower || ("найди" in lower && ("гугл" in lower || "интернете" in lower)) || "поищи в интернете" in lower) {
            val query = lower.replace("загугли","").replace("найди","").replace("в гугле","")
                .replace("в интернете","").replace("поищи","").trim()
            return if (query.isNotBlank()) searchGoogle(ctx, query) else "Что искать, сэр?"
        }

        // URL
        if ("открой сайт" in lower || "перейди на" in lower || "зайди на" in lower || "сайт" in lower && ("открой" in lower || "открыть" in lower)) {
            val url = lower.replace("открой сайт","").replace("перейди на","").replace("зайди на","")
                .replace("открой","").replace("сайт","").trim()
            return if (url.isNotBlank()) openUrl(ctx, url) else "Укажите адрес, сэр."
        }

        // ЗВОНОК
        if ("позвони" in lower || "набери" in lower || "вызови" in lower || "позвонить" in lower) {
            val num = lower.replace(Regex("[^0-9+]"), "").trim()
            return if (num.isNotBlank()) makeCall(ctx, num) else "Укажите номер телефона, сэр."
        }

        // БУДИЛЬНИК
        if ("будильник" in lower || "разбуди" in lower || "разбудить" in lower) {
            val time = extractTime(lower)
            return if (time != null) setAlarm(ctx, time.first, time.second) else "Укажите время для будильника, сэр."
        }

        // ТАЙМЕР
        if ("таймер" in lower || ("через" in lower && ("минут" in lower || "секунд" in lower || "час" in lower))) {
            val secs = extractSeconds(lower)
            return if (secs != null) setTimer(ctx, secs) else "Укажите время таймера, сэр."
        }

        // БАТАРЕЯ
        if ("батарея" in lower || "заряд" in lower || "зарядка" in lower || "батарейка" in lower) return getBattery(ctx)

        // ВРЕМЯ
        if ("время" in lower || "который час" in lower || "сколько времени" in lower || "час сейчас" in lower) {
            val c = java.util.Calendar.getInstance()
            return "Сейчас ${c.get(java.util.Calendar.HOUR_OF_DAY)}:${c.get(java.util.Calendar.MINUTE).toString().padStart(2,'0')}, сэр."
        }

        // ДАТА
        if ("дата" in lower || "какое число" in lower || "какой день" in lower || "число сегодня" in lower) {
            val c = java.util.Calendar.getInstance()
            val months = arrayOf("января","февраля","марта","апреля","мая","июня","июля","августа","сентября","октября","ноября","декабря")
            val days = arrayOf("воскресенье","понедельник","вторник","среда","четверг","пятница","суббота")
            return "Сегодня ${days[c.get(java.util.Calendar.DAY_OF_WEEK)-1]}, ${c.get(java.util.Calendar.DAY_OF_MONTH)} ${months[c.get(java.util.Calendar.MONTH)]} ${c.get(java.util.Calendar.YEAR)} года, сэр."
        }

        // УДАЛИТЬ
        if ("удали" in lower || "снеси" in lower || "удалить" in lower || "снести" in lower || "удали приложение" in lower) {
            val appName = lower.replace("удали","").replace("снеси","").replace("удалить","")
                .replace("снести","").replace("приложение","").trim()
            return if (appName.isNotBlank()) uninstallApp(ctx, appName) else "Укажите приложение для удаления, сэр."
        }

        // УВЕДОМЛЕНИЯ
        if ("уведомлени" in lower || "что пришло" in lower || "что нового" in lower || "новые сообщения" in lower) return getRecentNotifications()

        // ОТКРЫТЬ ПРИЛОЖЕНИЕ — максимально широкий парсер
        val openKeywords = listOf("открой", "запусти", "открыть", "запустить", "включи", "зайди в", "перейди в")
        for (kw in openKeywords) {
            if (kw in lower) {
                val appName = lower.replace(kw, "").replace("приложение", "").trim()
                if (appName.isNotBlank() && appName.length > 2) return openApp(ctx, appName)
            }
        }

        return null
    }
}
