package com.jarvis.ai.utils

import android.content.Context

object Prefs {
    private const val PREF = "jarvis_prefs"
    private const val KEY_API  = "api_key"
    private const val KEY_WAKE = "wake_word"

    fun saveApiKey(ctx: Context, key: String) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY_API, key).apply()
    fun getApiKey(ctx: Context): String = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_API, "") ?: ""

    fun saveWakeWord(ctx: Context, word: String) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY_WAKE, word).apply()
    fun getWakeWord(ctx: Context): String = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_WAKE, "джарвис") ?: "джарвис"
}
