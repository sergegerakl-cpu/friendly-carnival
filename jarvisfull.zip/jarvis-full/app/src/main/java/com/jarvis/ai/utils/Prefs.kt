package com.jarvis.ai.utils

import android.content.Context

object Prefs {
    private const val PREF = "jarvis_prefs"

    private const val KEY_API       = "api_key"
    private const val KEY_WAKE      = "wake_word"
    private const val KEY_MODEL     = "ai_model"
    private const val KEY_PITCH     = "tts_pitch"
    private const val KEY_SPEED     = "tts_speed"
    private const val KEY_COLOR     = "ui_color"
    private const val KEY_SCROLL_SP = "scroll_speed"
    private const val KEY_VIBRATE   = "vibrate"
    private const val KEY_AUTOSTART = "autostart"

    fun saveApiKey(ctx: Context, v: String) = put(ctx, KEY_API, v)
    fun getApiKey(ctx: Context): String = get(ctx, KEY_API, "")

    fun saveWakeWord(ctx: Context, v: String) = put(ctx, KEY_WAKE, v)
    fun getWakeWord(ctx: Context): String = get(ctx, KEY_WAKE, "джарвис")

    fun saveModel(ctx: Context, v: String) = put(ctx, KEY_MODEL, v)
    fun getModel(ctx: Context): String = get(ctx, KEY_MODEL, "gpt-4o-mini")

    fun savePitch(ctx: Context, v: Float) = putFloat(ctx, KEY_PITCH, v)
    fun getPitch(ctx: Context): Float = getFloat(ctx, KEY_PITCH, 0.8f)

    fun saveSpeed(ctx: Context, v: Float) = putFloat(ctx, KEY_SPEED, v)
    fun getSpeed(ctx: Context): Float = getFloat(ctx, KEY_SPEED, 0.9f)

    fun saveColor(ctx: Context, v: Int) = putInt(ctx, KEY_COLOR, v)
    fun getColor(ctx: Context): Int = getInt(ctx, KEY_COLOR, 0xFF00D4FF.toInt())

    fun saveScrollSpeed(ctx: Context, v: Int) = putInt(ctx, KEY_SCROLL_SP, v)
    fun getScrollSpeed(ctx: Context): Int = getInt(ctx, KEY_SCROLL_SP, 3500)

    fun saveVibrate(ctx: Context, v: Boolean) = putBool(ctx, KEY_VIBRATE, v)
    fun getVibrate(ctx: Context): Boolean = getBool(ctx, KEY_VIBRATE, true)

    fun saveAutostart(ctx: Context, v: Boolean) = putBool(ctx, KEY_AUTOSTART, v)
    fun getAutostart(ctx: Context): Boolean = getBool(ctx, KEY_AUTOSTART, false)

    private fun put(ctx: Context, key: String, value: String) =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(key, value).apply()
    private fun get(ctx: Context, key: String, def: String) =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(key, def) ?: def
    private fun putFloat(ctx: Context, key: String, value: Float) =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putFloat(key, value).apply()
    private fun getFloat(ctx: Context, key: String, def: Float) =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getFloat(key, def)
    private fun putInt(ctx: Context, key: String, value: Int) =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putInt(key, value).apply()
    private fun getInt(ctx: Context, key: String, def: Int) =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getInt(key, def)
    private fun putBool(ctx: Context, key: String, value: Boolean) =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean(key, value).apply()
    private fun getBool(ctx: Context, key: String, def: Boolean) =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(key, def)
}
