package com.jarvis.ai.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        var instance: JarvisAccessibilityService? = null
        var isScrolling = false
        private var scrollHandler = Handler(Looper.getMainLooper())
        private var scrollRunnable: Runnable? = null

        fun startScrolling(interval: Long = 3000L) {
            isScrolling = true
            val r = object : Runnable {
                override fun run() {
                    if (!isScrolling) return
                    instance?.swipeUp()
                    scrollHandler.postDelayed(this, interval)
                }
            }
            scrollRunnable = r
            scrollHandler.postDelayed(r, interval)
        }

        fun stopScrolling() {
            isScrolling = false
            scrollRunnable?.let { scrollHandler.removeCallbacks(it) }
        }
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun swipeUp() {
        val display = resources.displayMetrics
        val w = display.widthPixels
        val h = display.heightPixels

        val path = Path()
        path.moveTo(w / 2f, h * 0.75f)
        path.lineTo(w / 2f, h * 0.25f)

        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 400))
            .build()

        dispatchGesture(gesture, null, null)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
