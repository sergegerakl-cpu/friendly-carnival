package com.jarvis.ai.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        var instance: JarvisAccessibilityService? = null
        var isScrolling = false
        private val scrollHandler = Handler(Looper.getMainLooper())
        private var scrollRunnable: Runnable? = null

        fun startScrolling(intervalMs: Long = 3500L) {
            isScrolling = true
            val r = object : Runnable {
                override fun run() {
                    if (!isScrolling) return
                    instance?.swipeUp()
                    scrollHandler.postDelayed(this, intervalMs)
                }
            }
            scrollRunnable = r
            scrollHandler.postDelayed(r, 1500L) // первый свайп через 1.5 сек
        }

        fun stopScrolling() {
            isScrolling = false
            scrollRunnable?.let { scrollHandler.removeCallbacks(it) }
            scrollRunnable = null
        }
    }

    override fun onServiceConnected() {
        instance = this
    }

    fun swipeUp() {
        val dm = resources.displayMetrics
        val screenWidth = dm.widthPixels
        val screenHeight = dm.heightPixels

        // Свайп от 80% до 20% высоты экрана — большой и плавный
        val startX = (screenWidth * 0.5f)
        val startY = (screenHeight * 0.80f)
        val endY   = (screenHeight * 0.20f)

        val path = Path()
        path.moveTo(startX, startY)
        path.lineTo(startX, endY)

        val gesture = GestureDescription.Builder()
            .addStroke(
                GestureDescription.StrokeDescription(
                    path,
                    0L,    // startTime
                    600L   // duration ms — плавный свайп
                )
            )
            .build()

        dispatchGesture(gesture, null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        stopScrolling()
        instance = null
        super.onDestroy()
    }
}
