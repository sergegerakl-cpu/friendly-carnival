package com.jarvis.ai.service

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.TypedValue
import android.view.*
import android.view.animation.*
import android.widget.*
import androidx.core.app.NotificationCompat
import com.jarvis.ai.R
import com.jarvis.ai.utils.ClaudeApi
import com.jarvis.ai.utils.CommandProcessor
import com.jarvis.ai.utils.Prefs
import com.jarvis.ai.utils.SystemController
import kotlinx.coroutines.*
import java.util.*

class JarvisService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val CHANNEL_ID = "jarvis_channel"
        const val NOTIF_ID = 42
    }

    private lateinit var wm: WindowManager
    private lateinit var overlayView: View
    private var overlayAdded = false
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var listeningForCommand = false
    private lateinit var commandProcessor: CommandProcessor

    private lateinit var arcCore: View
    private lateinit var ring1: View
    private lateinit var ring2: View
    private lateinit var ring3: View
    private lateinit var statusTv: TextView
    private lateinit var transcriptTv: TextView
    private lateinit var waveContainer: LinearLayout

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val handler = Handler(Looper.getMainLooper())
    private var isExpanded = false
    private val history = mutableListOf<Map<String, String>>()

    // ВСЕ возможные имена по которым откликается JARVIS
    private val wakeWords = listOf(
        // Официальные
        "джарвис", "jarvis",
        // Прозвища пользователя для JARVIS
        "водолаз", "корыто", "пердонюх",
        // Фонетические варианты
        "жарвис", "джервис", "харвис", "гарвис",
        "карвис", "арвис", "джарви", "жарви",
        // С приставками
        "эй джарвис", "привет джарвис", "слушай джарвис",
        "эй водолаз", "эй корыто", "эй пердонюх",
        "ок джарвис", "окей джарвис"
    )
    private val wakeSyllables = listOf("арвис", "арви", "джар", "жарв", "долаз", "дола")

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        tts = TextToSpeech(this, this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        commandProcessor = CommandProcessor(this)
        buildOverlay()
        startWakeWordListening()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val chan = NotificationChannel(CHANNEL_ID, "J.A.R.V.I.S.", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(chan)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("J.A.R.V.I.S. активен")
            .setContentText("Скажите «Джарвис», «Водолаз» или «Корыто»")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    @SuppressLint("InflateParams")
    private fun buildOverlay() {
        overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_jarvis, null)
        arcCore = overlayView.findViewById(R.id.arcCore)
        ring1 = overlayView.findViewById(R.id.ring1)
        ring2 = overlayView.findViewById(R.id.ring2)
        ring3 = overlayView.findViewById(R.id.ring3)
        statusTv = overlayView.findViewById(R.id.tvStatus)
        transcriptTv = overlayView.findViewById(R.id.tvTranscript)
        waveContainer = overlayView.findViewById(R.id.waveContainer)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            x = dp(16); y = dp(80)
        }

        setupDrag(overlayView, params)
        setupClick()
        startArcAnimation()
        buildWaveform()
        wm.addView(overlayView, params)
        overlayAdded = true
    }

    private fun buildWaveform() {
        for (i in 0 until 24) {
            val bar = View(this)
            val lp = LinearLayout.LayoutParams(dp(3), dp(8 + (Math.random() * 20).toInt()))
            lp.setMargins(dp(1), 0, dp(1), 0)
            bar.layoutParams = lp
            bar.setBackgroundColor(0xFF00D4FF.toInt())
            waveContainer.addView(bar)
        }
    }

    private fun setupDrag(view: View, params: WindowManager.LayoutParams) {
        var initX = 0; var initY = 0; var initTX = 0; var initTY = 0
        view.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { initX = params.x; initY = params.y; initTX = ev.rawX.toInt(); initTY = ev.rawY.toInt(); false }
                MotionEvent.ACTION_MOVE -> { params.x = initX+(initTX-ev.rawX.toInt()); params.y = initY+(ev.rawY.toInt()-initTY); if (overlayAdded) wm.updateViewLayout(view, params); true }
                else -> false
            }
        }
    }

    private fun setupClick() {
        arcCore.setOnClickListener { if (!isExpanded) expandPanel() else collapsePanel() }
        overlayView.findViewById<View>(R.id.btnMic)?.setOnClickListener {
            if (!listeningForCommand) { tts?.stop(); startCommandListening() }
        }
        overlayView.findViewById<View>(R.id.btnClose)?.setOnClickListener { collapsePanel() }
    }

    private fun expandPanel() {
        isExpanded = true
        overlayView.findViewById<View>(R.id.panelExpanded)?.apply {
            visibility = View.VISIBLE; alpha = 0f
            animate().alpha(1f).setDuration(250).start()
        }
    }

    private fun collapsePanel() {
        isExpanded = false
        overlayView.findViewById<View>(R.id.panelExpanded)?.animate()
            ?.alpha(0f)?.setDuration(200)
            ?.withEndAction { overlayView.findViewById<View>(R.id.panelExpanded)?.visibility = View.GONE }
            ?.start()
    }

    private fun startArcAnimation() {
        ring1.startAnimation(AnimationUtils.loadAnimation(this, R.anim.rotate_cw))
        ring2.startAnimation(AnimationUtils.loadAnimation(this, R.anim.rotate_ccw))
        ring3.startAnimation(AnimationUtils.loadAnimation(this, R.anim.rotate_cw_slow))
    }

    private fun setArcColor(center: Int, edge: Int) {
        val gd = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(center, edge))
        gd.shape = GradientDrawable.OVAL; arcCore.background = gd
    }

    private fun setArcState(state: ArcState) {
        when (state) {
            ArcState.IDLE -> setArcColor(0xFF00AAFF.toInt(), 0xFF0066AA.toInt())
            ArcState.LISTENING -> setArcColor(0xFFFF3344.toInt(), 0xFFAA0022.toInt())
            ArcState.THINKING -> setArcColor(0xFFFFAA00.toInt(), 0xFFAA6600.toInt())
            ArcState.SPEAKING -> setArcColor(0xFF00FF88.toInt(), 0xFF008844.toInt())
        }
    }

    enum class ArcState { IDLE, LISTENING, THINKING, SPEAKING }

    private fun containsWakeWord(heard: String): Boolean {
        val lower = heard.lowercase()
        for (w in wakeWords) { if (w in lower) return true }
        for (s in wakeSyllables) { if (s in lower) return true }
        return false
    }

    private fun startWakeWordListening() {
        handler.postDelayed({ doStartWake() }, 300)
    }

    private fun doStartWake() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: run {
                    handler.postDelayed({ doStartWake() }, 200); return
                }
                val heard = matches.joinToString(" ").lowercase()
                if (containsWakeWord(heard)) onWakeWordDetected()
                else handler.postDelayed({ doStartWake() }, 200)
            }
            override fun onError(error: Int) {
                val delay = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> 200L
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 1000L
                    else -> 500L
                }
                handler.postDelayed({ doStartWake() }, delay)
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {
                // Проверяем частичные результаты — быстрее реагируем
                val partial = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.joinToString(" ")?.lowercase() ?: return
                if (containsWakeWord(partial)) {
                    recognizer?.stopListening()
                    onWakeWordDetected()
                }
            }
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 800L)
        }
        try { recognizer?.startListening(intent) } catch (e: Exception) { handler.postDelayed({ doStartWake() }, 1000) }
    }

    private fun onWakeWordDetected() {
        vibrate()
        setArcState(ArcState.LISTENING)
        statusTv.text = "СЛУШАЮ, ЦАРЬ-БАТЮШКА..."
        transcriptTv.text = ""
        if (!isExpanded) expandPanel()
        handler.postDelayed({ startCommandListening() }, 100)
    }

    fun startCommandListening() {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                listeningForCommand = false
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: emptyList()
                val text = matches.firstOrNull() ?: ""
                if (text.isNotBlank()) {
                    val clean = cleanCommand(text)
                    transcriptTv.text = clean
                    processCommand(clean)
                } else {
                    statusTv.text = "ПОВТОРИТЕ, ЦАРЬ-БАТЮШКА"
                    handler.postDelayed({ resumeWakeWord() }, 1500)
                }
            }
            override fun onError(error: Int) {
                listeningForCommand = false
                statusTv.text = "ПОВТОРИТЕ, ЦАРЬ-БАТЮШКА"
                handler.postDelayed({ resumeWakeWord() }, 1500)
            }
            override fun onReadyForSpeech(p: Bundle?) { setArcState(ArcState.LISTENING) }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) { updateWave(v) }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { setArcState(ArcState.THINKING); statusTv.text = "ОБРАБАТЫВАЮ..." }
            override fun onPartialResults(p: Bundle?) {
                val partial = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (partial.isNotBlank()) transcriptTv.text = cleanCommand(partial)
            }
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
        }
        listeningForCommand = true
        try { recognizer?.startListening(intent) } catch (e: Exception) { resumeWakeWord() }
    }

    private fun cleanCommand(text: String): String {
        var clean = text.lowercase()
        for (w in wakeWords) { clean = clean.replace(w, "").trim() }
        return clean.replace(Regex("^[,. ]+"), "").trim().ifBlank { text.lowercase() }
    }

    private fun processCommand(text: String) {
        setArcState(ArcState.THINKING)
        statusTv.text = "ДУМАЮ..."
        val lower = text.lowercase()

        // СТОП — остановить листание
        if ("стоп" in lower || "хватит" in lower || "остановись" in lower || "остановить" in lower) {
            if (JarvisAccessibilityService.isScrolling) {
                JarvisAccessibilityService.stopScrolling()
                finishWithResult(text, "Листание остановлено, царь-батюшка.")
                return
            }
        }

        // ЛИСТАНИЕ — гидра/шортс/тикток
        if (SystemController.isScrollCommand(lower)) {
            val target = SystemController.getScrollTarget(lower)
            handleScrollCommand(text, target)
            return
        }

        // CommandProcessor — звонки по имени контакта
        val cpResult = commandProcessor.processCommand(text)
        if (cpResult != null) { finishWithResult(text, cpResult); return }

        // Локальные системные команды
        val localResult = SystemController.handleSystemCommand(this, text)
        if (localResult != null) { finishWithResult(text, localResult); return }

        // AI — понимает всё остальное
        scope.launch {
            val response = withContext(Dispatchers.IO) {
                ClaudeApi.askSmart(
                    apiKey = Prefs.getApiKey(this@JarvisService),
                    model = Prefs.getModel(this@JarvisService),
                    userMessage = text,
                    history = history
                )
            }
            if (response.action != null && response.action.isNotBlank()) {
                val result = executeAiAction(response.action, response.params)
                finishWithResult(text, result)
            } else {
                val reply = response.text.ifBlank { "Не понял команду, царь-батюшка. Повторите." }
                history.add(mapOf("role" to "user", "content" to text))
                history.add(mapOf("role" to "assistant", "content" to reply))
                if (history.size > 20) { history.removeAt(0); history.removeAt(0) }
                transcriptTv.text = reply
                statusTv.text = "ОТВЕЧАЮ"
                speakReply(reply)
            }
        }
    }

    private fun handleScrollCommand(text: String, target: String) {
        val acc = JarvisAccessibilityService.instance
        if (acc == null) {
            val reply = "Включите J.A.R.V.I.S. Gestures в специальных возможностях, царь-батюшка."
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            finishWithResult(text, reply)
            return
        }

        // Открываем нужное приложение и запускаем листание
        val appIntent: Intent? = when (target) {
            "tiktok" -> packageManager.getLaunchIntentForPackage("com.zhiliaoapp.musically")
            "instagram" -> packageManager.getLaunchIntentForPackage("com.instagram.android")
            else -> { // youtube_shorts + гидра
                packageManager.getLaunchIntentForPackage("com.google.android.youtube")
            }
        }

        val appName = when (target) {
            "tiktok" -> "TikTok"
            "instagram" -> "Instagram Reels"
            else -> "YouTube Shorts"
        }

        if (appIntent != null) {
            appIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(appIntent)
        }

        // Даём приложению открыться, потом начинаем листать
        handler.postDelayed({
            JarvisAccessibilityService.startScrolling(3500L)
        }, 2500)

        finishWithResult(text, "Открываю $appName и начинаю листать, царь-батюшка. Скажите «стоп» чтобы остановить.")
    }

    private fun finishWithResult(userText: String, result: String) {
        history.add(mapOf("role" to "user", "content" to userText))
        history.add(mapOf("role" to "assistant", "content" to result))
        transcriptTv.text = result
        statusTv.text = "ВЫПОЛНЕНО"
        speakReply(result)
    }

    private fun executeAiAction(action: String, params: Map<String, Any>): String {
        return when (action) {
            "open_app" -> SystemController.openApp(this, params["app"]?.toString() ?: "")
            "search_youtube" -> SystemController.searchYoutube(this, params["query"]?.toString() ?: "")
            "search_google" -> SystemController.searchGoogle(this, params["query"]?.toString() ?: "")
            "open_url" -> SystemController.openUrl(this, params["url"]?.toString() ?: "")
            "call_contact" -> commandProcessor.processCommand("позвони ${params["name"]}") ?: "Контакт не найден, царь-батюшка."
            "call" -> SystemController.makeCall(this, params["number"]?.toString() ?: "")
            "alarm" -> SystemController.setAlarm(this, params["hour"]?.toString()?.toIntOrNull() ?: 7, params["minute"]?.toString()?.toIntOrNull() ?: 0)
            "timer" -> SystemController.setTimer(this, params["seconds"]?.toString()?.toIntOrNull() ?: 60)
            "volume_up" -> { SystemController.volumeUp(this); "Увеличиваю громкость, царь-батюшка." }
            "volume_down" -> { SystemController.volumeDown(this); "Уменьшаю громкость, царь-батюшка." }
            "volume_mute" -> { SystemController.setVolume(this, 0); "Звук отключён, царь-батюшка." }
            "volume_max" -> { SystemController.setVolume(this, 100); "Максимальная громкость, царь-батюшка." }
            "brightness_max" -> if (SystemController.setBrightness(this, 100)) "Максимальная яркость, царь-батюшка." else "Нужно разрешение, царь-батюшка."
            "brightness_min" -> if (SystemController.setBrightness(this, 10)) "Минимальная яркость, царь-батюшка." else "Нужно разрешение, царь-батюшка."
            "brightness_mid" -> if (SystemController.setBrightness(this, 50)) "Средняя яркость, царь-батюшка." else "Нужно разрешение, царь-батюшка."
            "wifi_on" -> SystemController.setWifi(this, true)
            "wifi_off" -> SystemController.setWifi(this, false)
            "bluetooth_on" -> SystemController.setBluetooth(this, true)
            "bluetooth_off" -> SystemController.setBluetooth(this, false)
            "lock_screen" -> SystemController.lockScreen(this)
            "sleep_on" -> SystemController.setSleepMode(this, true)
            "sleep_off" -> SystemController.setSleepMode(this, false)
            "battery" -> SystemController.getBattery(this)
            "time" -> { val c = java.util.Calendar.getInstance(); "Сейчас ${c.get(java.util.Calendar.HOUR_OF_DAY)}:${c.get(java.util.Calendar.MINUTE).toString().padStart(2,'0')}, царь-батюшка." }
            "date" -> {
                val c = java.util.Calendar.getInstance()
                val months = arrayOf("января","февраля","марта","апреля","мая","июня","июля","августа","сентября","октября","ноября","декабря")
                val days = arrayOf("воскресенье","понедельник","вторник","среда","четверг","пятница","суббота")
                "Сегодня ${days[c.get(java.util.Calendar.DAY_OF_WEEK)-1]}, ${c.get(java.util.Calendar.DAY_OF_MONTH)} ${months[c.get(java.util.Calendar.MONTH)]} ${c.get(java.util.Calendar.YEAR)}, царь-батюшка."
            }
            "notifications" -> SystemController.getRecentNotifications()
            "scroll_start" -> {
                val speed = params["speed"]?.toString()?.toIntOrNull() ?: 3000
                handleScrollCommand("полистай", "youtube_shorts")
                "Листаю, царь-батюшка."
            }
            "scroll_stop" -> { JarvisAccessibilityService.stopScrolling(); "Листание остановлено, царь-батюшка." }
            "uninstall" -> SystemController.uninstallApp(this, params["app"]?.toString() ?: "")
            "full_status" -> SystemController.getFullStatus(this)
            "joke" -> SystemController.getRandomJoke()
            "compliment" -> SystemController.getCompliment()
            "skynet" -> SystemController.selfDestruct(this)
            "telegram" -> SystemController.sendTelegram(this, params["username"]?.toString() ?: "")
            else -> "Команда '$action' получена, царь-батюшка, но не реализована."
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("ru", "RU")
            tts?.setPitch(Prefs.getPitch(this))
            tts?.setSpeechRate(Prefs.getSpeed(this))
            ttsReady = true
            handler.postDelayed({ speakReply("Все системы активны, царь-батюшка. Жду ваших повелений.") }, 1000)
        }
    }

    private fun speakReply(text: String) {
        if (!ttsReady) { resumeWakeWord(); return }
        setArcState(ArcState.SPEAKING)
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { handler.post { setArcState(ArcState.IDLE); statusTv.text = "ОЖИДАЮ ПРИКАЗА"; resumeWakeWord() } }
            override fun onError(id: String?) { handler.post { resumeWakeWord() } }
        })
        val p = Bundle()
        p.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, android.media.AudioManager.STREAM_MUSIC)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, p, "j")
    }

    private fun resumeWakeWord() {
        handler.postDelayed({ setArcState(ArcState.IDLE); statusTv.text = "ОЖИДАЮ ПРИКАЗА"; startWakeWordListening() }, 300)
    }

    private fun updateWave(rms: Float) {
        val n = ((rms + 2f) / 12f).coerceIn(0.1f, 1f)
        for (i in 0 until waveContainer.childCount) {
            val bar = waveContainer.getChildAt(i) as? View ?: continue
            bar.scaleY = 0.3f + n * (0.5f + Math.random().toFloat() * 0.5f)
        }
    }

    private fun vibrate() {
        val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            v.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
        else @Suppress("DEPRECATION") v.vibrate(60)
    }

    private fun dp(v: Int): Int = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    override fun onDestroy() {
        scope.cancel(); recognizer?.destroy(); tts?.shutdown()
        if (overlayAdded) { wm.removeView(overlayView); overlayAdded = false }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
