package com.jarvis.ai.service

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.TypedValue
import android.view.*
import android.view.animation.*
import android.widget.*
import androidx.core.app.NotificationCompat
import com.jarvis.ai.R
import com.jarvis.ai.utils.ClaudeApi
import com.jarvis.ai.utils.Prefs
import com.jarvis.ai.utils.SystemController
import kotlinx.coroutines.*
import java.util.*

class JarvisService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val CHANNEL_ID = "jarvis_channel"
        const val NOTIF_ID   = 42
    }

    private lateinit var wm: WindowManager
    private lateinit var overlayView: View
    private var overlayAdded = false

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var listeningForCommand = false

    private lateinit var arcCore: View
    private lateinit var ring1: View
    private lateinit var ring2: View
    private lateinit var ring3: View
    private lateinit var statusTv: TextView
    private lateinit var transcriptTv: TextView
    private lateinit var waveContainer: LinearLayout

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val handler = Handler(Looper.getMainLooper())
    private var isExpanded = false
    private val history = mutableListOf<Map<String, String>>()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        tts = TextToSpeech(this, this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildOverlay()
        startWakeWordListening()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val chan = NotificationChannel(CHANNEL_ID, "J.A.R.V.I.S.", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(chan)
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("J.A.R.V.I.S. активен")
            .setContentText("Скажите «${Prefs.getWakeWord(this)}» для активации")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    @SuppressLint("InflateParams")
    private fun buildOverlay() {
        overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_jarvis, null)
        arcCore       = overlayView.findViewById(R.id.arcCore)
        ring1         = overlayView.findViewById(R.id.ring1)
        ring2         = overlayView.findViewById(R.id.ring2)
        ring3         = overlayView.findViewById(R.id.ring3)
        statusTv      = overlayView.findViewById(R.id.tvStatus)
        transcriptTv  = overlayView.findViewById(R.id.tvTranscript)
        waveContainer = overlayView.findViewById(R.id.waveContainer)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            x = dp(16); y = dp(80)
        }

        setupDrag(overlayView, params)
        setupClick()
        startArcAnimation()
        buildWaveform()
        wm.addView(overlayView, params)
        overlayAdded = true
    }

    private fun buildWaveform() {
        for (i in 0 until 24) {
            val bar = View(this)
            val lp = LinearLayout.LayoutParams(dp(3), dp(8 + (Math.random() * 20).toInt()))
            lp.setMargins(dp(1), 0, dp(1), 0)
            bar.layoutParams = lp
            bar.setBackgroundColor(0xFF00D4FF.toInt())
            waveContainer.addView(bar)
        }
    }

    private fun setupDrag(view: View, params: WindowManager.LayoutParams) {
        var initX = 0; var initY = 0; var initTX = 0; var initTY = 0
        view.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { initX = params.x; initY = params.y; initTX = ev.rawX.toInt(); initTY = ev.rawY.toInt(); false }
                MotionEvent.ACTION_MOVE -> { params.x = initX + (initTX - ev.rawX.toInt()); params.y = initY + (ev.rawY.toInt() - initTY); if (overlayAdded) wm.updateViewLayout(view, params); true }
                else -> false
            }
        }
    }

    private fun setupClick() {
        arcCore.setOnClickListener {
            if (!isExpanded) expandPanel() else collapsePanel()
        }
        overlayView.findViewById<View>(R.id.btnMic)?.setOnClickListener {
            if (!listeningForCommand) startCommandListening()
        }
        overlayView.findViewById<View>(R.id.btnClose)?.setOnClickListener { collapsePanel() }
    }

    private fun expandPanel() {
        isExpanded = true
        overlayView.findViewById<View>(R.id.panelExpanded)?.visibility = View.VISIBLE
        overlayView.findViewById<View>(R.id.panelExpanded)?.animate()?.alpha(1f)?.setDuration(300)?.start()
    }

    private fun collapsePanel() {
        isExpanded = false
        overlayView.findViewById<View>(R.id.panelExpanded)?.animate()?.alpha(0f)?.setDuration(200)
            ?.withEndAction { overlayView.findViewById<View>(R.id.panelExpanded)?.visibility = View.GONE }?.start()
    }

    private fun startArcAnimation() {
        ring1.startAnimation(AnimationUtils.loadAnimation(this, R.anim.rotate_cw))
        ring2.startAnimation(AnimationUtils.loadAnimation(this, R.anim.rotate_ccw))
        ring3.startAnimation(AnimationUtils.loadAnimation(this, R.anim.rotate_cw_slow))
    }

    private fun setArcState(state: ArcState) {
        val (c, e) = when (state) {
            ArcState.IDLE      -> 0xFF00AAFF.toInt() to 0xFF0066AA.toInt()
            ArcState.LISTENING -> 0xFFFF3344.toInt() to 0xFFAA0022.toInt()
            ArcState.THINKING  -> 0xFFFFAA00.toInt() to 0xFFAA6600.toInt()
            ArcState.SPEAKING  -> 0xFF00FF88.toInt() to 0xFF008844.toInt()
        }
        val gd = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(c, e))
        gd.shape = GradientDrawable.OVAL
        arcCore.background = gd
    }

    enum class ArcState { IDLE, LISTENING, THINKING, SPEAKING }

    private fun startWakeWordListening() {
        handler.postDelayed({ doStartWake() }, 500)
    }

    private fun doStartWake() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
                val wakeWord = Prefs.getWakeWord(this@JarvisService).lowercase()
                val heard = matches.joinToString(" ").lowercase()
                if (wakeWord in heard || "джарвис" in heard || "jarvis" in heard) {
                    onWakeWordDetected()
                } else {
                    handler.postDelayed({ doStartWake() }, 300)
                }
            }
            override fun onError(error: Int) { handler.postDelayed({ doStartWake() }, 1000) }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
        }
        recognizer?.startListening(intent)
    }

    private fun onWakeWordDetected() {
        vibrate()
        setArcState(ArcState.LISTENING)
        statusTv.text = "СЛУШАЮ..."
        transcriptTv.text = ""
        if (!isExpanded) expandPanel()
        handler.postDelayed({ startCommandListening() }, 300)
    }

    fun startCommandListening() {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                listeningForCommand = false
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (text.isNotBlank()) {
                    transcriptTv.text = text
                    processCommand(text)
                } else {
                    statusTv.text = "НЕ УСЛЫШАЛ"
                    handler.postDelayed({ resumeWakeWord() }, 1500)
                }
            }
            override fun onError(error: Int) { listeningForCommand = false; statusTv.text = "ОШИБКА"; handler.postDelayed({ resumeWakeWord() }, 1500) }
            override fun onReadyForSpeech(p: Bundle?) { setArcState(ArcState.LISTENING) }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) { updateWave(v) }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { setArcState(ArcState.THINKING); statusTv.text = "ОБРАБАТЫВАЮ..." }
            override fun onPartialResults(p: Bundle?) {
                val partial = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                transcriptTv.text = partial
            }
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        listeningForCommand = true
        recognizer?.startListening(intent)
    }

    private fun processCommand(text: String) {
        setArcState(ArcState.THINKING)
        statusTv.text = "ДУМАЮ..."

        // First check if it's a system command
        val sysResult = SystemController.handleSystemCommand(this, text)
        if (sysResult != null) {
            transcriptTv.text = sysResult
            statusTv.text = "ВЫПОЛНЕНО"
            speakReply(sysResult)
            return
        }

        // Otherwise ask AI
        scope.launch {
            val reply = withContext(Dispatchers.IO) {
                ClaudeApi.ask(
                    apiKey = Prefs.getApiKey(this@JarvisService),
                    userMessage = text,
                    history = history
                )
            }
            history.add(mapOf("role" to "user", "content" to text))
            history.add(mapOf("role" to "assistant", "content" to reply))
            if (history.size > 20) { history.removeAt(0); history.removeAt(0) }
            transcriptTv.text = reply
            statusTv.text = "ОТВЕЧАЮ"
            speakReply(reply)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("ru", "RU")
            tts?.setPitch(0.85f)
            tts?.setSpeechRate(0.9f)
            ttsReady = true
            // Greet on start
            handler.postDelayed({
                val greeting = "Системы инициализированы, сэр. Все модули активны."
                speakReply(greeting)
            }, 1000)
        }
    }

    private fun speakReply(text: String) {
        if (!ttsReady) { resumeWakeWord(); return }
        setArcState(ArcState.SPEAKING)
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { handler.post { setArcState(ArcState.IDLE); statusTv.text = "ОЖИДАЮ"; resumeWakeWord() } }
            override fun onError(id: String?) { handler.post { resumeWakeWord() } }
        })
        val params = Bundle().apply { putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, android.media.AudioManager.STREAM_MUSIC) }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "jarvis_reply")
    }

    private fun resumeWakeWord() {
        handler.postDelayed({ setArcState(ArcState.IDLE); statusTv.text = "ОЖИДАЮ КОМАНДУ"; startWakeWordListening() }, 500)
    }

    private fun updateWave(rms: Float) {
        val normalized = ((rms + 2f) / 12f).coerceIn(0.1f, 1f)
        for (i in 0 until waveContainer.childCount) {
            val bar = waveContainer.getChildAt(i) as? View ?: continue
            val factor = 0.3f + normalized * (0.5f + Math.random().toFloat() * 0.5f)
            bar.scaleY = factor
        }
    }

    private fun vibrate() {
        val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
        } else { @Suppress("DEPRECATION") v.vibrate(80) }
    }

    private fun dp(v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    override fun onDestroy() {
        scope.cancel()
        recognizer?.destroy()
        tts?.shutdown()
        if (overlayAdded) { wm.removeView(overlayView); overlayAdded = false }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
