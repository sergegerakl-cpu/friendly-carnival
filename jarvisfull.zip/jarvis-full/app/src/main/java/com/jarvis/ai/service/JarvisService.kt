
package com.jarvis.ai.service

import com.jarvis.ai.utils.ClaudeApi

// Этот класс обрабатывает запросы и команды от пользователя
class JarvisService {

    // Список слов для активации (wake words)
    private val wakeWords = listOf("водолаз", "пердани", "корыто", "ошибка эволюции")
    // Список слогов, которые могут быть использованы для распознавания
    private val wakeSyllables = listOf("во", "да", "лаз", "пер", "да", "ни", "ко", "ры", "то", "ош", "и", "ка", "э", "во", "лю", "ци", "я")

    // Основной метод, который обрабатывает сообщение пользователя
    fun handleMessage(userMessage: String): JarvisResponse {
        // Проверяем, содержит ли сообщение одно из слов в списке wakeWords
        if (wakeWords.any { userMessage.contains(it, ignoreCase = true) }) {
            return JarvisResponse("Привет, царь батюшка! Готов служить.")
        }

        // Если нет, передаем сообщение на обработку в ClaudeApi
        val response = ClaudeApi.askSmart(apiKey = "your-api-key", userMessage = userMessage, history = emptyList())
        return response
    }
}