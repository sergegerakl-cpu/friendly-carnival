package com.jarvis.ai.service

import com.jarvis.ai.utils.ClaudeApi.JarvisResponse  // Добавляем правильный импорт

class JarvisService {

    private val wakeWords = listOf("водолаз", "пердани корыто", "ошибка эволюции")
    private val wakeSyllables = listOf("во", "да", "лаз", "пер", "да", "ни", "ко", "ры", "то", "ош", "и", "ка", "э", "во", "лю", "ци", "я")

    fun handleMessage(userMessage: String): JarvisResponse {
        if (wakeWords.any { userMessage.contains(it, ignoreCase = true) }) {
            return JarvisResponse("Привет, царь батюшка! Готов служить.")
        }
        
        // Здесь обрабатываем запрос через ClaudeApi
        val response = ClaudeApi.askSmart(apiKey = "your-api-key", userMessage = userMessage, history = emptyList())
        return response
    }
}