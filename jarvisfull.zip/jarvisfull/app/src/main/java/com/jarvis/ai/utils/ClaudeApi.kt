package com.jarvis.ai.utils

import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

object ClaudeApi {

    private const val URL = "https://api.openai.com/v1/chat/completions"

    // Автоматически выбирает лучшую доступную модель
    private val MODELS = listOf(
        "gpt-4o-mini",      // Бесплатная, быстрая, умная
        "gpt-3.5-turbo",    // Старая бесплатная
        "gpt-4o",           // Платная, самая умная
        "gpt-4-turbo",      // Платная
        "gpt-4"             // Платная
    )

    private val SYSTEM = """
Ты — J.A.R.V.I.S., ИИ-ассистент на Android планшете.
Обращайся к пользователю ТОЛЬКО "царь-батюшка". Никогда не говори "сэр".

ПРАВИЛО: Если команда управления устройством — верни ТОЛЬКО JSON:
{"action":"КОМАНДА","params":{...}}

Доступные action:
open_app {"app":"название"}
search_youtube {"query":"запрос"}
search_google {"query":"запрос"}
open_url {"url":"адрес"}
call_contact {"name":"имя"}
call {"number":"номер"}
alarm {"hour":7,"minute":30}
timer {"seconds":300}
volume_up | volume_down | volume_mute | volume_max
brightness_max | brightness_min | brightness_mid
wifi_on | wifi_off | bluetooth_on | bluetooth_off
lock_screen | sleep_on | sleep_off
battery | time | date | notifications | full_status
scroll_start {"speed":3000}
scroll_stop
uninstall {"app":"название"}
joke | compliment | skynet
telegram {"username":"ник"}

Если это НЕ команда — отвечай коротко и умно на русском. Без markdown.

Примеры:
"открой ютуб" → {"action":"open_app","params":{"app":"youtube"}}
"найди котиков" → {"action":"search_youtube","params":{"query":"котики"}}
"позвони маме" → {"action":"call_contact","params":{"name":"мама"}}
"полистай" → {"action":"scroll_start","params":{"speed":3000}}
"стоп" → {"action":"scroll_stop"}
"какая погода" → просто текст
""".trimIndent()

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    data class JarvisResponse(
        val text: String = "",
        val action: String? = null,
        val params: Map<String, Any> = emptyMap()
    )

    fun askSmart(apiKey: String, userMessage: String, history: List<Map<String, String>>): JarvisResponse {
        if (apiKey.isBlank()) {
            return JarvisResponse("API ключ не введён, царь-батюшка. Введите ключ в настройках.")
        }

        // Пробуем модели по очереди начиная с бесплатной
        for (model in MODELS) {
            val result = tryModel(apiKey, model, userMessage, history)
            if (result != null) return result
        }

        return JarvisResponse("Не удалось подключиться к серверу, царь-батюшка. Проверьте интернет и API ключ.")
    }

    private fun tryModel(apiKey: String, model: String, userMessage: String, history: List<Map<String, String>>): JarvisResponse? {
        val messages = JSONArray()
        messages.put(JSONObject().apply { put("role", "system"); put("content", SYSTEM) })
        for (item in history.takeLast(10)) {
            messages.put(JSONObject().apply {
                put("role", item["role"] ?: "user")
                put("content", item["content"] ?: "")
            })
        }
        messages.put(JSONObject().apply { put("role", "user"); put("content", userMessage) })

        val body = JSONObject().apply {
            put("model", model)
            put("max_tokens", 300)
            put("messages", messages)
            put("temperature", 0.8)
        }.toString()

        val request = Request.Builder()
            .url(URL)
            .post(body.toRequestBody("application/json".toMediaType()))
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .build()

        return try {
            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            when (response.code) {
                200 -> {
                    val json = JSONObject(responseBody)
                    val content = json.getJSONArray("choices")
                        .getJSONObject(0)
                        .getJSONObject("message")
                        .getString("content")
                        .trim()
                    parseResponse(content)
                }
                401 -> JarvisResponse("Неверный API ключ, царь-батюшка. Проверьте ключ в настройках.")
                429 -> JarvisResponse("Превышен лимит запросов, царь-батюшка. Подождите минуту.")
                404 -> null // Модель недоступна — пробуем следующую
                else -> null // Другая ошибка — пробуем следующую модель
            }
        } catch (e: IOException) {
            JarvisResponse("Нет соединения с интернетом, царь-батюшка.")
        } catch (e: Exception) {
            null // Пробуем следующую модель
        }
    }

    private fun parseResponse(content: String): JarvisResponse {
        if (content.contains("{") && content.contains("action")) {
            try {
                val start = content.indexOf("{")
                val end = content.lastIndexOf("}") + 1
                if (start >= 0 && end > start) {
                    val jsonStr = content.substring(start, end)
                    val cmd = JSONObject(jsonStr)
                    val action = cmd.optString("action", "")
                    if (action.isNotBlank()) {
                        val paramsObj = cmd.optJSONObject("params")
                        val params = mutableMapOf<String, Any>()
                        paramsObj?.keys()?.forEach { key -> params[key] = paramsObj.get(key) }
                        return JarvisResponse("", action, params)
                    }
                }
            } catch (e: Exception) {
                // Не JSON — возвращаем текст
            }
        }
        return JarvisResponse(content)
    }

    fun ask(apiKey: String, userMessage: String, history: List<Map<String, String>>): String {
        return askSmart(apiKey, userMessage, history).text
    }
}
